import type { Config } from "tailwindcss";

// Colour system inspired by international humanitarian / NGO dashboards:
// a strong accessible red as the primary brand accent on a clean white/grey
// surface, with clear semantic colours for feedback status & priority.
// This is a generic humanitarian palette, not a reproduction of any
// organisation's protected brand assets.
const config: Config = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#fdf2f2",
          100: "#fce4e4",
          200: "#f9caca",
          300: "#f3a3a3",
          400: "#ea6f6f",
          500: "#d92b2b", // primary brand red
          600: "#c11f1f",
          700: "#a01818",
          800: "#7f1616",
          900: "#691616",
          950: "#390808",
        },
        surface: {
          DEFAULT: "#ffffff",
          muted: "#f7f7f8",
          subtle: "#f1f2f4",
        },
        ink: {
          DEFAULT: "#1a1c1e",
          muted: "#5b6169",
          faint: "#8a919a",
        },
        status: {
          new: "#2563eb",
          inProgress: "#d97706",
          resolved: "#16a34a",
          closed: "#6b7280",
          escalated: "#c11f1f",
        },
      },
      fontFamily: {
        sans: [
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
      },
      boxShadow: {
        card: "0 1px 2px 0 rgba(20, 20, 22, 0.04), 0 1px 3px 0 rgba(20, 20, 22, 0.06)",
      },
      borderRadius: {
        xl: "0.875rem",
      },
    },
  },
  plugins: [],
};

export default config;
