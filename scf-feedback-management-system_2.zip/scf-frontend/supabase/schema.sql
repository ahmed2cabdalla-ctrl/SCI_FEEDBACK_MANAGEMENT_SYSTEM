-- Reference schema for Supabase's role in this app: staff authentication only.
--
-- Every other table this app used to keep in Postgres (sectors, locations,
-- projects, beneficiaries, feedback, hotline_calls) has moved to Airtable —
-- see /airtable/schema.md for that schema. Supabase now exists purely to
-- authenticate staff and to store the `profiles` row (name + role) attached
-- to each Supabase Auth user.

create extension if not exists "pgcrypto";

-- Extends Supabase's built-in auth.users with app-specific profile fields.
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null,
  role text not null default 'viewer'
    check (role in ('admin', 'accountability_officer', 'program_staff', 'viewer')),
  avatar_url text,
  location_id text, -- an Airtable Location record id (rec...), not a Postgres foreign key
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "users read own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);

-- A signed-in user can update their own profile (e.g. avatar); role changes
-- should generally go through an admin-only path once the Users module is
-- built, not this open policy — tighten this before relying on it.
create policy "users update own profile" on public.profiles
  for update to authenticated using (auth.uid() = id);
