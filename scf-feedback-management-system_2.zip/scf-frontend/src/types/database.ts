/**
 * Supabase schema types.
 *
 * Supabase is used ONLY for staff authentication and the `profiles` table
 * in this app — every other table (feedback, sectors, projects, locations,
 * beneficiaries, hotline calls) lives in Airtable instead (see
 * /airtable/schema.md and src/lib/airtable/*). If your `profiles` table
 * differs, regenerate this file from your real project:
 *
 *   npx supabase gen types typescript --project-id <your-project-ref> > src/types/database.ts
 */

export type UserRole = "admin" | "accountability_officer" | "program_staff" | "viewer";

export type ProfileRow = {
  id: string;
  full_name: string;
  role: UserRole;
  avatar_url: string | null;
  location_id: string | null;
  is_active: boolean;
  created_at: string;
};

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: ProfileRow;
        Insert: Partial<ProfileRow> & Pick<ProfileRow, "id" | "full_name" | "role">;
        Update: Partial<ProfileRow>;
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
  };
};
