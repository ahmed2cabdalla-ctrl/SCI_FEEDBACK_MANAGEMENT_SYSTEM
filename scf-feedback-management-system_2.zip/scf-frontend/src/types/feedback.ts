/**
 * Domain enums for feedback records. These describe the business data
 * (now stored in Airtable — see /airtable/schema.md), not Supabase, which
 * is only used for staff login and profiles (see src/types/database.ts).
 */

export type FeedbackType = "complaint" | "compliment" | "suggestion" | "inquiry";

export type FeedbackChannel =
  | "hotline"
  | "in_person"
  | "suggestion_box"
  | "sms"
  | "email"
  | "community_meeting"
  | "other";

export type FeedbackSensitivity = "sensitive" | "non_sensitive";

export type FeedbackPriority = "low" | "medium" | "high" | "critical";

export type FeedbackStatus = "new" | "in_progress" | "resolved" | "closed" | "escalated";
