export * from "./database";
export * from "./feedback";

import type {
  FeedbackChannel,
  FeedbackPriority,
  FeedbackSensitivity,
  FeedbackStatus,
  FeedbackType,
} from "./feedback";

/** Flat, UI-friendly shape used across dashboard widgets and tables — mapped from an Airtable record. */
export interface FeedbackRecord {
  id: string; // Airtable record id (recXXXXXXXXXXXXXX)
  referenceCode: string;
  type: FeedbackType;
  category: string | null;
  channel: FeedbackChannel;
  sensitivity: FeedbackSensitivity;
  priority: FeedbackPriority;
  status: FeedbackStatus;
  isAnonymous: boolean;
  description: string;
  sectorName: string | null;
  projectName: string | null;
  locationName: string | null;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
}

export interface DashboardStats {
  totalFeedback: number;
  newCount: number;
  inProgressCount: number;
  resolvedCount: number;
  escalatedCount: number;
  sensitiveCount: number;
  resolutionRate: number; // 0-100
}

export interface TrendPoint {
  date: string; // ISO date (day)
  label: string; // display label, e.g. "Sep 03"
  total: number;
}

export interface CategoryCount {
  name: string;
  value: number;
}

export interface StatusCount {
  status: FeedbackStatus;
  label: string;
  value: number;
}

/** Generic async data state used by data-fetching hooks throughout the app. */
export type AsyncState<T> =
  | { status: "loading"; data: null; error: null }
  | { status: "error"; data: null; error: string }
  | { status: "empty"; data: T; error: null }
  | { status: "success"; data: T; error: null };

export interface NavItem {
  label: string;
  href: string;
  icon: keyof typeof import("lucide-react");
}

export interface SelectOption {
  label: string;
  value: string;
}
