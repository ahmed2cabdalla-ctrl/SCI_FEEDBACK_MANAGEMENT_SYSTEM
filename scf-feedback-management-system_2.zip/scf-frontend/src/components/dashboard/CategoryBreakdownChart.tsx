"use client";

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardBody, CardHeader } from "@/components/ui";
import { EmptyState } from "@/components/ui";
import type { CategoryCount } from "@/types";

export function CategoryBreakdownChart({ data }: { data: CategoryCount[] }) {
  return (
    <Card>
      <CardHeader title="Top feedback categories" description="Last 14 days" />
      <CardBody>
        {data.length === 0 ? (
          <EmptyState title="No category data yet" description="Categorised feedback will appear here." />
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data}
                layout="vertical"
                margin={{ top: 0, right: 16, left: 0, bottom: 0 }}
              >
                <CartesianGrid horizontal={false} stroke="#eef0f2" />
                <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12, fill: "#8a919a" }} axisLine={false} tickLine={false} />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={120}
                  tick={{ fontSize: 12, fill: "#1a1c1e" }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  cursor={{ fill: "#f7f7f8" }}
                  contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 13 }}
                />
                <Bar dataKey="value" name="Reports" fill="#d92b2b" radius={[0, 4, 4, 0]} maxBarSize={18} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardBody>
    </Card>
  );
}
