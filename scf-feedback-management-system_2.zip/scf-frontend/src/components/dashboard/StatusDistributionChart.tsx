"use client";

import { Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardBody, CardHeader } from "@/components/ui";
import type { StatusCount } from "@/types";

// Solid hex equivalents of the STATUS_COLORS tailwind tokens, for Recharts fills.
const STATUS_HEX: Record<string, string> = {
  new: "#2563eb",
  in_progress: "#d97706",
  resolved: "#16a34a",
  closed: "#6b7280",
  escalated: "#d92b2b",
};

export function StatusDistributionChart({ data }: { data: StatusCount[] }) {
  const total = data.reduce((sum, d) => sum + d.value, 0);

  return (
    <Card>
      <CardHeader title="Status distribution" description="All open and closed cases" />
      <CardBody>
        {total === 0 ? (
          <p className="py-10 text-center text-sm text-ink-muted">No feedback recorded yet.</p>
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="label"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={2}
                >
                  {data.map((entry) => (
                    <Cell key={entry.status} fill={STATUS_HEX[entry.status]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb", fontSize: 13 }} />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  formatter={(value) => <span className="text-xs text-ink-muted">{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardBody>
    </Card>
  );
}
