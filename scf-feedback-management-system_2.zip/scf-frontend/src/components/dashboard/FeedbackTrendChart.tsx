"use client";

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardBody, CardHeader } from "@/components/ui";
import type { TrendPoint } from "@/types";

export function FeedbackTrendChart({ data }: { data: TrendPoint[] }) {
  return (
    <Card>
      <CardHeader
        title="Feedback volume"
        description="Submissions received over the last 14 days"
      />
      <CardBody>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
              <defs>
                <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#d92b2b" stopOpacity={0.25} />
                  <stop offset="100%" stopColor="#d92b2b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} stroke="#eef0f2" />
              <XAxis
                dataKey="label"
                tick={{ fontSize: 12, fill: "#8a919a" }}
                axisLine={false}
                tickLine={false}
                interval="preserveStartEnd"
              />
              <YAxis
                allowDecimals={false}
                tick={{ fontSize: 12, fill: "#8a919a" }}
                axisLine={false}
                tickLine={false}
                width={32}
              />
              <Tooltip
                cursor={{ stroke: "#d92b2b", strokeWidth: 1, strokeDasharray: "4 4" }}
                contentStyle={{
                  borderRadius: 8,
                  border: "1px solid #e5e7eb",
                  fontSize: 13,
                }}
              />
              <Area
                type="monotone"
                dataKey="total"
                name="Submissions"
                stroke="#d92b2b"
                strokeWidth={2}
                fill="url(#trendFill)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardBody>
    </Card>
  );
}
