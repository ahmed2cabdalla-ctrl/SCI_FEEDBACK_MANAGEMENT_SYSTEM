import { AlertOctagon, CheckCircle2, Inbox, ShieldAlert, TimerReset } from "lucide-react";
import { StatCard } from "@/components/ui";
import type { DashboardStats } from "@/types";

export function StatsOverview({ stats }: { stats: DashboardStats }) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
      <StatCard label="Total feedback" value={stats.totalFeedback} icon={Inbox} accent="brand" />
      <StatCard label="New" value={stats.newCount} icon={AlertOctagon} accent="blue" />
      <StatCard label="In progress" value={stats.inProgressCount} icon={TimerReset} accent="amber" />
      <StatCard
        label="Resolved"
        value={stats.resolvedCount}
        icon={CheckCircle2}
        accent="green"
        hint={`${stats.resolutionRate}% resolution rate`}
      />
      <StatCard
        label="Sensitive cases"
        value={stats.sensitiveCount}
        icon={ShieldAlert}
        accent="brand"
        hint={`${stats.escalatedCount} escalated`}
      />
    </div>
  );
}
