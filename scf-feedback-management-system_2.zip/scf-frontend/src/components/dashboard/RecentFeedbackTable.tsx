"use client";

import { PriorityBadge, StatusBadge } from "@/components/ui/Badge";
import { DataTable, type Column } from "@/components/ui/Table";
import { CHANNEL_LABELS, TYPE_LABELS } from "@/lib/constants/labels";
import { formatDateTime } from "@/lib/utils/date";
import type { FeedbackRecord } from "@/types";

export function RecentFeedbackTable({ rows }: { rows: FeedbackRecord[] }) {
  const columns: Column<FeedbackRecord>[] = [
    {
      key: "reference",
      header: "Reference",
      render: (r) => (
        <div>
          <p className="font-medium text-ink">{r.referenceCode}</p>
          <p className="text-xs text-ink-faint">{TYPE_LABELS[r.type]}</p>
        </div>
      ),
    },
    {
      key: "description",
      header: "Summary",
      className: "max-w-xs truncate",
      render: (r) => (
        <span className="line-clamp-1 max-w-xs text-ink-muted">{r.description}</span>
      ),
      hideOnMobile: true,
    },
    {
      key: "channel",
      header: "Channel",
      render: (r) => <span className="text-ink-muted">{CHANNEL_LABELS[r.channel]}</span>,
      hideOnMobile: true,
    },
    {
      key: "priority",
      header: "Priority",
      render: (r) => <PriorityBadge priority={r.priority} />,
    },
    {
      key: "status",
      header: "Status",
      render: (r) => <StatusBadge status={r.status} />,
    },
    {
      key: "created",
      header: "Received",
      render: (r) => <span className="text-ink-muted">{formatDateTime(r.createdAt)}</span>,
      hideOnMobile: true,
    },
  ];

  return (
    <div>
      <div className="mb-3">
        <h3 className="text-sm font-semibold text-ink">Recent feedback</h3>
        <p className="mt-0.5 text-sm text-ink-muted">The 8 most recently submitted cases</p>
      </div>
      <DataTable
        columns={columns}
        rows={rows}
        rowKey={(r) => r.id}
        status="success"
        emptyTitle="No feedback yet"
        emptyDescription="Submitted feedback will show up here as soon as it comes in."
      />
    </div>
  );
}
