import type { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/Card";

/**
 * Scaffold placeholder for modules not built out yet (Beneficiaries, Sectors,
 * Projects, Locations, Hotline, Reports, Users, Settings). Each of these
 * routes already exists and renders inside the shared DashboardShell — swap
 * this out for the real page as each module is implemented, reusing the
 * Card / DataTable / FilterBar / Modal / FormField components already built.
 */
export function ModulePlaceholder({
  icon: Icon,
  title,
  description,
  plannedFeatures,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  plannedFeatures: string[];
}) {
  return (
    <Card className="p-8">
      <div className="flex flex-col items-start gap-4">
        <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
          <Icon className="h-5 w-5" aria-hidden="true" />
        </span>
        <div>
          <h2 className="text-base font-semibold text-ink">{title}</h2>
          <p className="mt-1 max-w-xl text-sm text-ink-muted">{description}</p>
        </div>
        <div className="w-full rounded-lg border border-dashed border-gray-300 bg-surface-muted p-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-faint">
            Planned for this module
          </p>
          <ul className="mt-2 space-y-1.5 text-sm text-ink-muted">
            {plannedFeatures.map((feature) => (
              <li key={feature} className="flex items-start gap-2">
                <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-ink-faint" />
                {feature}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Card>
  );
}
