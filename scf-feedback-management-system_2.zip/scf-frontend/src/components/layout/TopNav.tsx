"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Bell, LogOut, Menu, UserCircle } from "lucide-react";
import { useAuth } from "@/lib/auth/AuthProvider";
import { cn } from "@/lib/utils/cn";

export function TopNav({ onMenuClick, title }: { onMenuClick: () => void; title?: string }) {
  const { user, profile, signOut } = useAuth();
  const router = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    router.push("/login");
  };

  const displayName = profile?.full_name || user?.email || "Account";

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-gray-200 bg-white/95 px-4 backdrop-blur sm:px-6 lg:pl-6">
      <button
        type="button"
        onClick={onMenuClick}
        aria-label="Open navigation menu"
        className="rounded-lg p-2 text-ink-muted hover:bg-surface-muted lg:hidden"
      >
        <Menu className="h-5 w-5" aria-hidden="true" />
      </button>

      <h1 className="min-w-0 flex-1 truncate text-base font-semibold text-ink sm:text-lg">
        {title}
      </h1>

      <button
        type="button"
        aria-label="Notifications"
        className="rounded-lg p-2 text-ink-muted hover:bg-surface-muted"
      >
        <Bell className="h-5 w-5" aria-hidden="true" />
      </button>

      <div className="relative">
        <button
          type="button"
          onClick={() => setMenuOpen((v) => !v)}
          aria-haspopup="menu"
          aria-expanded={menuOpen}
          className="flex items-center gap-2 rounded-lg py-1.5 pl-1.5 pr-2 hover:bg-surface-muted"
        >
          <UserCircle className="h-7 w-7 text-ink-faint" aria-hidden="true" />
          <span className="hidden max-w-[140px] truncate text-sm font-medium text-ink sm:block">
            {displayName}
          </span>
        </button>

        <div
          role="menu"
          className={cn(
            "absolute right-0 mt-2 w-48 overflow-hidden rounded-lg border border-gray-200 bg-white py-1 shadow-lg",
            menuOpen ? "block" : "hidden"
          )}
        >
          <div className="border-b border-gray-100 px-3 py-2">
            <p className="truncate text-sm font-medium text-ink">{displayName}</p>
            {profile?.role ? (
              <p className="truncate text-xs capitalize text-ink-faint">
                {profile.role.replace(/_/g, " ")}
              </p>
            ) : null}
          </div>
          <button
            role="menuitem"
            onClick={handleSignOut}
            className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-ink-muted hover:bg-surface-muted hover:text-ink"
          >
            <LogOut className="h-4 w-4" aria-hidden="true" />
            Sign out
          </button>
        </div>
      </div>
    </header>
  );
}
