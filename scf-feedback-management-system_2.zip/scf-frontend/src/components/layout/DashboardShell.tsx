"use client";

import { useState, type ReactNode } from "react";
import { usePathname } from "next/navigation";
import { X } from "lucide-react";
import { NAV_ITEMS, NAV_ITEMS_ADMIN } from "@/lib/constants/nav";
import { Sidebar, SidebarContent } from "./Sidebar";
import { TopNav } from "./TopNav";

/**
 * Overall authenticated app shell: fixed desktop sidebar + slide-over mobile
 * drawer + sticky top nav + scrollable content area. Wrap every page under
 * the (app) route group with this. The top nav title is derived from the
 * current route automatically; pass `title` to override it.
 */
export function DashboardShell({ title, children }: { title?: string; children: ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const pathname = usePathname();
  const activeNavItem = [...NAV_ITEMS, ...NAV_ITEMS_ADMIN].find(
    (item) => pathname === item.href || pathname.startsWith(`${item.href}/`)
  );
  const resolvedTitle = title ?? activeNavItem?.label ?? "Feedback Management System";

  return (
    <div className="min-h-screen bg-surface-muted">
      <Sidebar />

      {/* Mobile drawer */}
      {drawerOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setDrawerOpen(false)}
            aria-hidden="true"
          />
          <div className="absolute inset-y-0 left-0 flex w-72 flex-col bg-white shadow-xl">
            <button
              type="button"
              onClick={() => setDrawerOpen(false)}
              aria-label="Close navigation menu"
              className="absolute right-3 top-4 rounded-lg p-1.5 text-ink-muted hover:bg-surface-muted"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
            <SidebarContent onNavigate={() => setDrawerOpen(false)} />
          </div>
        </div>
      ) : null}

      <div className="lg:pl-64">
        <TopNav onMenuClick={() => setDrawerOpen(true)} title={resolvedTitle} />
        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
