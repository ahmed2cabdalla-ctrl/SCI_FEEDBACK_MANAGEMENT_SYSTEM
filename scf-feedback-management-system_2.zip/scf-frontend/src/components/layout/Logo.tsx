import { HeartHandshake } from "lucide-react";

/**
 * Placeholder organisation mark.
 *
 * This is a generic humanitarian icon + wordmark — NOT the Save the
 * Children logo. Per the brief, real Save the Children (or any other)
 * brand assets must be supplied by the organisation and dropped in here
 * (e.g. swap the <span> icon below for an <Image src="/logo.svg" .../>).
 */
export function Logo({ collapsed = false }: { collapsed?: boolean }) {
  return (
    <div className="flex items-center gap-2.5 overflow-hidden">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-white">
        <HeartHandshake className="h-5 w-5" aria-hidden="true" />
      </span>
      {!collapsed && (
        <span className="flex flex-col leading-tight">
          <span className="text-sm font-bold text-ink">Feedback Mgmt.</span>
          <span className="text-[11px] font-medium text-ink-faint">Accountability System</span>
        </span>
      )}
    </div>
  );
}
