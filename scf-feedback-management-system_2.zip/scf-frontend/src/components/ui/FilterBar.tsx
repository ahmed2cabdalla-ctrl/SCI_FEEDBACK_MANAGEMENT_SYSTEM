"use client";

import { Search, SlidersHorizontal, X } from "lucide-react";
import type { SelectOption } from "@/types";
import { cn } from "@/lib/utils/cn";

export interface FilterConfig {
  key: string;
  label: string;
  options: SelectOption[];
}

interface FilterBarProps {
  searchValue: string;
  onSearchChange: (value: string) => void;
  searchPlaceholder?: string;
  filters: FilterConfig[];
  activeValues: Record<string, string>;
  onFilterChange: (key: string, value: string) => void;
  onClear?: () => void;
}

/**
 * Reusable search + dropdown-filter bar used across list pages
 * (Feedback, Beneficiaries, Hotline, Reports, ...).
 */
export function FilterBar({
  searchValue,
  onSearchChange,
  searchPlaceholder = "Search…",
  filters,
  activeValues,
  onFilterChange,
  onClear,
}: FilterBarProps) {
  const hasActiveFilters =
    !!searchValue || Object.values(activeValues).some((v) => v && v !== "all");

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-gray-200 bg-white p-3 sm:flex-row sm:flex-wrap sm:items-center">
      <div className="relative flex-1 sm:min-w-[220px]">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-faint"
          aria-hidden="true"
        />
        <input
          type="search"
          value={searchValue}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={searchPlaceholder}
          aria-label="Search"
          className="h-10 w-full rounded-lg border border-gray-300 bg-white pl-9 pr-3 text-sm text-ink placeholder:text-ink-faint focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
        />
      </div>

      <div className="flex flex-1 flex-wrap items-center gap-2">
        <SlidersHorizontal className="hidden h-4 w-4 shrink-0 text-ink-faint sm:block" aria-hidden="true" />
        {filters.map((filter) => (
          <select
            key={filter.key}
            value={activeValues[filter.key] ?? "all"}
            onChange={(e) => onFilterChange(filter.key, e.target.value)}
            aria-label={filter.label}
            className={cn(
              "h-9 rounded-lg border border-gray-300 bg-white px-3 text-sm text-ink focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
            )}
          >
            <option value="all">All {filter.label.toLowerCase()}</option>
            {filter.options.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        ))}

        {hasActiveFilters && onClear ? (
          <button
            type="button"
            onClick={onClear}
            className="inline-flex h-9 items-center gap-1 rounded-lg px-2.5 text-sm font-medium text-ink-muted hover:bg-surface-muted hover:text-ink"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
            Clear
          </button>
        ) : null}
      </div>
    </div>
  );
}
