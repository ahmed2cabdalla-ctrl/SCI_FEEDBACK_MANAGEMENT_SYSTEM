import type { NavItem } from "@/types";

/** Primary sidebar navigation. Order here is the order rendered. */
export const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: "LayoutDashboard" },
  { label: "Feedback", href: "/feedback", icon: "MessagesSquare" },
  { label: "Beneficiaries", href: "/beneficiaries", icon: "Users" },
  { label: "Sectors", href: "/sectors", icon: "LayoutGrid" },
  { label: "Projects", href: "/projects", icon: "FolderKanban" },
  { label: "Locations", href: "/locations", icon: "MapPin" },
  { label: "Hotline", href: "/hotline", icon: "PhoneCall" },
  { label: "Reports", href: "/reports", icon: "BarChart3" },
];

/** Administration-only section, rendered separately at the bottom of the sidebar. */
export const NAV_ITEMS_ADMIN: NavItem[] = [
  { label: "Users", href: "/users", icon: "UserCog" },
  { label: "Settings", href: "/settings", icon: "Settings" },
];
