import type {
  FeedbackChannel,
  FeedbackPriority,
  FeedbackSensitivity,
  FeedbackStatus,
  FeedbackType,
} from "@/types/feedback";

export const STATUS_LABELS: Record<FeedbackStatus, string> = {
  new: "New",
  in_progress: "In progress",
  resolved: "Resolved",
  closed: "Closed",
  escalated: "Escalated",
};

export const STATUS_COLORS: Record<FeedbackStatus, string> = {
  new: "bg-blue-50 text-blue-700 ring-blue-600/20",
  in_progress: "bg-amber-50 text-amber-700 ring-amber-600/20",
  resolved: "bg-green-50 text-green-700 ring-green-600/20",
  closed: "bg-gray-100 text-gray-600 ring-gray-500/20",
  escalated: "bg-brand-50 text-brand-700 ring-brand-600/20",
};

export const PRIORITY_LABELS: Record<FeedbackPriority, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

export const PRIORITY_COLORS: Record<FeedbackPriority, string> = {
  low: "bg-gray-100 text-gray-600 ring-gray-500/20",
  medium: "bg-blue-50 text-blue-700 ring-blue-600/20",
  high: "bg-amber-50 text-amber-700 ring-amber-600/20",
  critical: "bg-brand-50 text-brand-700 ring-brand-600/20",
};

export const TYPE_LABELS: Record<FeedbackType, string> = {
  complaint: "Complaint",
  compliment: "Compliment",
  suggestion: "Suggestion",
  inquiry: "Inquiry",
};

export const CHANNEL_LABELS: Record<FeedbackChannel, string> = {
  hotline: "Hotline",
  in_person: "In person",
  suggestion_box: "Suggestion box",
  sms: "SMS",
  email: "Email",
  community_meeting: "Community meeting",
  other: "Other",
};

export const SENSITIVITY_LABELS: Record<FeedbackSensitivity, string> = {
  non_sensitive: "Non-sensitive",
  sensitive: "Sensitive",
};

export const CHART_COLORS = [
  "#d92b2b",
  "#2563eb",
  "#16a34a",
  "#d97706",
  "#7c3aed",
  "#0891b2",
  "#6b7280",
];
