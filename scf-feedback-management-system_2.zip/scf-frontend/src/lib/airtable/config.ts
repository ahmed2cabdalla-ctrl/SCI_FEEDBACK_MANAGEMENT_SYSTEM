import "server-only";

let hasWarned = false;

/**
 * Resolves Airtable connection details from SERVER-ONLY env vars.
 *
 * IMPORTANT: these must never be prefixed with NEXT_PUBLIC_ and must never
 * be read from a Client Component — an Airtable Personal Access Token
 * grants full read/write on your base with no row-level security, unlike
 * Supabase's anon key. All Airtable access in this app happens inside
 * Next.js Route Handlers (src/app/api/**) which run only on the server.
 *
 * Doesn't throw when unconfigured, for the same reason as
 * src/lib/supabase/config.ts: a missing env var should surface as this
 * app's own error state, not a hard crash (including during `next build`).
 */
export function getAirtableConfig() {
  const token = process.env.AIRTABLE_PERSONAL_ACCESS_TOKEN;
  const baseId = process.env.AIRTABLE_BASE_ID;
  const isConfigured = Boolean(token && baseId);

  if (!isConfigured && !hasWarned) {
    hasWarned = true;
    // eslint-disable-next-line no-console
    console.warn(
      "[Feedback Management System] AIRTABLE_PERSONAL_ACCESS_TOKEN / AIRTABLE_BASE_ID are not set. " +
        "Copy .env.local.example to .env.local and add your Airtable credentials — until then, " +
        "every Airtable-backed API route will return an error response."
    );
  }

  return {
    token: token || "",
    baseId: baseId || "",
    isConfigured,
  };
}
