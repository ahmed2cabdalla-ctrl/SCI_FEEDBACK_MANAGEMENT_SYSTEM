import "server-only";
import {
  CHANNEL_LABELS,
  PRIORITY_LABELS,
  SENSITIVITY_LABELS,
  STATUS_LABELS,
  TYPE_LABELS,
} from "@/lib/constants/labels";

/**
 * Airtable Single Select fields store human-readable choice text (e.g.
 * "In progress"), matching exactly what's typed into the choice list when
 * setting up the base (see /airtable/schema.md) — so non-technical staff
 * editing records directly in Airtable see friendly labels, not enum
 * codes. These helpers translate between that text and this app's
 * internal enum values (e.g. "in_progress"), reusing the same label maps
 * the UI already uses so there's exactly one place that spells them out.
 */
function buildReverseMap<K extends string>(labels: Record<K, string>): Map<string, K> {
  return new Map(Object.entries(labels).map(([key, label]) => [label as string, key as K]));
}

const STATUS_REVERSE = buildReverseMap(STATUS_LABELS);
const PRIORITY_REVERSE = buildReverseMap(PRIORITY_LABELS);
const TYPE_REVERSE = buildReverseMap(TYPE_LABELS);
const CHANNEL_REVERSE = buildReverseMap(CHANNEL_LABELS);
const SENSITIVITY_REVERSE = buildReverseMap(SENSITIVITY_LABELS);

export function statusFromAirtable(label: string | undefined) {
  return (label && STATUS_REVERSE.get(label)) || "new";
}
export function priorityFromAirtable(label: string | undefined) {
  return (label && PRIORITY_REVERSE.get(label)) || "medium";
}
export function typeFromAirtable(label: string | undefined) {
  return (label && TYPE_REVERSE.get(label)) || "inquiry";
}
export function channelFromAirtable(label: string | undefined) {
  return (label && CHANNEL_REVERSE.get(label)) || "other";
}
export function sensitivityFromAirtable(label: string | undefined) {
  return (label && SENSITIVITY_REVERSE.get(label)) || "non_sensitive";
}
