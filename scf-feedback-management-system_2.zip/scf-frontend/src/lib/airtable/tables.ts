/**
 * Airtable table and field name constants. Keep these in sync with the
 * base you set up per /airtable/schema.md — table/field names are matched
 * by exact string, so a typo here (or a renamed column in Airtable) will
 * show up as "field not found"-style errors from the Airtable API.
 */

export const TABLES = {
  SECTORS: "Sectors",
  LOCATIONS: "Locations",
  PROJECTS: "Projects",
  BENEFICIARIES: "Beneficiaries",
  FEEDBACK: "Feedback",
  HOTLINE_CALLS: "Hotline Calls",
} as const;

export const SECTOR_FIELDS = {
  NAME: "Name",
  DESCRIPTION: "Description",
} as const;

export const LOCATION_FIELDS = {
  NAME: "Name",
  TYPE: "Type",
  PARENT: "Parent",
} as const;

export const PROJECT_FIELDS = {
  NAME: "Name",
  CODE: "Code",
  SECTOR: "Sector",
  LOCATION: "Location",
  STATUS: "Status",
} as const;

export const BENEFICIARY_FIELDS = {
  UNIQUE_CODE: "Unique Code",
  FULL_NAME: "Full Name",
  GENDER: "Gender",
  AGE_GROUP: "Age Group",
  LOCATION: "Location",
  PROJECT: "Project",
  CONTACT_PHONE: "Contact Phone",
} as const;

export const FEEDBACK_FIELDS = {
  REFERENCE_CODE: "Reference Code",
  TYPE: "Type",
  CATEGORY: "Category",
  SECTOR: "Sector",
  SECTOR_NAME: "Sector Name", // lookup field, from Sector -> Name
  PROJECT: "Project",
  PROJECT_NAME: "Project Name", // lookup field, from Project -> Name
  LOCATION: "Location",
  LOCATION_NAME: "Location Name", // lookup field, from Location -> Name
  BENEFICIARY: "Beneficiary",
  CHANNEL: "Channel",
  SENSITIVITY: "Sensitivity",
  PRIORITY: "Priority",
  STATUS: "Status",
  IS_ANONYMOUS: "Is Anonymous",
  DESCRIPTION: "Description",
  RESPONSE: "Response",
  SUBMITTED_BY: "Submitted By",
  ASSIGNED_TO: "Assigned To",
  RESOLVED_AT: "Resolved At",
} as const;

export const HOTLINE_CALL_FIELDS = {
  CALLER_REFERENCE: "Caller Reference",
  CALL_TYPE: "Call Type",
  DURATION_SECONDS: "Duration Seconds",
  FEEDBACK: "Feedback",
  HANDLED_BY: "Handled By",
  NOTES: "Notes",
} as const;
