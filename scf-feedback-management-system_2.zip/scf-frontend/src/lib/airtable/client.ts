import "server-only";
import { getAirtableConfig } from "./config";

const API_ROOT = "https://api.airtable.com/v0";

export interface AirtableRecord<Fields extends Record<string, unknown>> {
  id: string;
  createdTime: string;
  fields: Fields;
}

interface ListResponse<Fields extends Record<string, unknown>> {
  records: AirtableRecord<Fields>[];
  offset?: string;
}

export class AirtableNotConfiguredError extends Error {
  constructor() {
    super(
      "Airtable is not configured. Set AIRTABLE_PERSONAL_ACCESS_TOKEN and AIRTABLE_BASE_ID in .env.local."
    );
    this.name = "AirtableNotConfiguredError";
  }
}

async function airtableFetch(path: string, init: RequestInit = {}, attempt = 0): Promise<Response> {
  const { token, baseId, isConfigured } = getAirtableConfig();
  if (!isConfigured) throw new AirtableNotConfiguredError();

  const res = await fetch(`${API_ROOT}/${baseId}/${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...init.headers,
    },
    cache: "no-store",
  });

  // Airtable allows 5 requests/sec per base — back off once on a 429 rather
  // than failing a page load outright.
  if (res.status === 429 && attempt < 2) {
    await new Promise((resolve) => setTimeout(resolve, 300 * (attempt + 1)));
    return airtableFetch(path, init, attempt + 1);
  }

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`Airtable request failed (${res.status}): ${body || res.statusText}`);
  }

  return res;
}

/** Fetches every record in a table (paginating through Airtable's 100-record pages), optionally filtered/sorted. */
export async function listAllRecords<Fields extends Record<string, unknown>>(
  table: string,
  params: { filterByFormula?: string; sort?: { field: string; direction?: "asc" | "desc" }[] } = {}
): Promise<AirtableRecord<Fields>[]> {
  const records: AirtableRecord<Fields>[] = [];
  let offset: string | undefined;

  do {
    const search = new URLSearchParams();
    search.set("pageSize", "100");
    if (offset) search.set("offset", offset);
    if (params.filterByFormula) search.set("filterByFormula", params.filterByFormula);
    params.sort?.forEach((s, i) => {
      search.set(`sort[${i}][field]`, s.field);
      search.set(`sort[${i}][direction]`, s.direction ?? "asc");
    });

    const res = await airtableFetch(`${encodeURIComponent(table)}?${search.toString()}`);
    const json = (await res.json()) as ListResponse<Fields>;
    records.push(...json.records);
    offset = json.offset;
  } while (offset);

  return records;
}

/** Creates a single record and returns it as Airtable stored it (with generated id/createdTime). */
export async function createRecord<Fields extends Record<string, unknown>>(
  table: string,
  fields: Partial<Fields>
): Promise<AirtableRecord<Fields>> {
  const res = await airtableFetch(encodeURIComponent(table), {
    method: "POST",
    body: JSON.stringify({ records: [{ fields }], typecast: true }),
  });
  const json = (await res.json()) as ListResponse<Fields>;
  return json.records[0];
}
