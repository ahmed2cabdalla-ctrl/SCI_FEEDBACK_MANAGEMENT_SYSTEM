import "server-only";
import type { AirtableRecord } from "./client";
import { FEEDBACK_FIELDS } from "./tables";
import {
  channelFromAirtable,
  priorityFromAirtable,
  sensitivityFromAirtable,
  statusFromAirtable,
  typeFromAirtable,
} from "./valueMaps";
import type { FeedbackRecord, SelectOption } from "@/types";

/**
 * Raw shape of a Feedback record's `fields` as Airtable returns it.
 *
 * Airtable OMITS empty/false/unset fields from the API response entirely
 * (rather than sending null/false) — every field here is optional to
 * reflect that; the mapper below fills in sensible defaults.
 */
export type AirtableFeedbackFields = {
  [FEEDBACK_FIELDS.REFERENCE_CODE]?: string;
  [FEEDBACK_FIELDS.TYPE]?: string;
  [FEEDBACK_FIELDS.CATEGORY]?: string;
  [FEEDBACK_FIELDS.SECTOR]?: string[];
  [FEEDBACK_FIELDS.SECTOR_NAME]?: string[];
  [FEEDBACK_FIELDS.PROJECT]?: string[];
  [FEEDBACK_FIELDS.PROJECT_NAME]?: string[];
  [FEEDBACK_FIELDS.LOCATION]?: string[];
  [FEEDBACK_FIELDS.LOCATION_NAME]?: string[];
  [FEEDBACK_FIELDS.BENEFICIARY]?: string[];
  [FEEDBACK_FIELDS.CHANNEL]?: string;
  [FEEDBACK_FIELDS.SENSITIVITY]?: string;
  [FEEDBACK_FIELDS.PRIORITY]?: string;
  [FEEDBACK_FIELDS.STATUS]?: string;
  [FEEDBACK_FIELDS.IS_ANONYMOUS]?: boolean;
  [FEEDBACK_FIELDS.DESCRIPTION]?: string;
  [FEEDBACK_FIELDS.RESPONSE]?: string;
  [FEEDBACK_FIELDS.SUBMITTED_BY]?: string;
  [FEEDBACK_FIELDS.ASSIGNED_TO]?: string;
  [FEEDBACK_FIELDS.RESOLVED_AT]?: string;
};

/** Maps a raw Airtable Feedback record to the flat shape the UI uses. */
export function mapFeedbackRecord(record: AirtableRecord<AirtableFeedbackFields>): FeedbackRecord {
  const f = record.fields;
  return {
    id: record.id,
    referenceCode: f[FEEDBACK_FIELDS.REFERENCE_CODE] ?? record.id,
    type: typeFromAirtable(f[FEEDBACK_FIELDS.TYPE]),
    category: f[FEEDBACK_FIELDS.CATEGORY] ?? null,
    channel: channelFromAirtable(f[FEEDBACK_FIELDS.CHANNEL]),
    sensitivity: sensitivityFromAirtable(f[FEEDBACK_FIELDS.SENSITIVITY]),
    priority: priorityFromAirtable(f[FEEDBACK_FIELDS.PRIORITY]),
    status: statusFromAirtable(f[FEEDBACK_FIELDS.STATUS]),
    isAnonymous: f[FEEDBACK_FIELDS.IS_ANONYMOUS] ?? false,
    description: f[FEEDBACK_FIELDS.DESCRIPTION] ?? "",
    sectorName: f[FEEDBACK_FIELDS.SECTOR_NAME]?.[0] ?? null,
    projectName: f[FEEDBACK_FIELDS.PROJECT_NAME]?.[0] ?? null,
    locationName: f[FEEDBACK_FIELDS.LOCATION_NAME]?.[0] ?? null,
    createdAt: record.createdTime,
    updatedAt: record.createdTime,
    resolvedAt: f[FEEDBACK_FIELDS.RESOLVED_AT] ?? null,
  };
}

/** Maps a simple `{Name: string}` lookup table (Sectors/Projects/Locations) to a dropdown option. */
export function mapNamedRecordToOption(
  record: AirtableRecord<{ Name?: string }>
): SelectOption {
  return { value: record.id, label: record.fields.Name ?? "(untitled)" };
}
