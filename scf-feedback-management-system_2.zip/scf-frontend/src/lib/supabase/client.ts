"use client";

import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@/types/database";
import { getSupabaseConfig } from "./config";

/**
 * Supabase client for use in Client Components (browser).
 * Reads the project URL/anon key from public env vars — see .env.local.example.
 */
export function createClient() {
  const { url, anonKey } = getSupabaseConfig();
  return createBrowserClient<Database>(url, anonKey);
}
