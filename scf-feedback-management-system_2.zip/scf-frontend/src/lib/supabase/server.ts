import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { Database } from "@/types/database";
import { getSupabaseConfig } from "./config";

/**
 * Supabase client for use in Server Components, Route Handlers and Server Actions.
 * Must be created per-request (it reads/writes the request's cookies for the
 * auth session), so call this inside the component/handler — never module-scope it.
 */
export function createServerSupabaseClient() {
  const cookieStore = cookies();
  const { url, anonKey } = getSupabaseConfig();

  return createServerClient<Database>(url, anonKey, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options);
          });
        } catch {
          // Called from a Server Component with no writable cookie context —
          // safe to ignore because middleware refreshes the session anyway.
        }
      },
    },
  });
}
