let hasWarned = false;

/**
 * Resolves Supabase connection details from public env vars.
 *
 * Deliberately does NOT throw when they're missing: that would crash the
 * entire app (including the build's static prerender pass) before any UI
 * — including this app's own error states — gets a chance to render. If
 * the project isn't configured yet, we fall back to an obviously-fake
 * placeholder project so the Supabase client can be constructed; any real
 * query against it will fail over the network and surface through the
 * normal loading/error states built into each page.
 */
export function getSupabaseConfig() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const isConfigured = Boolean(url && anonKey);

  if (!isConfigured && !hasWarned) {
    hasWarned = true;
    // eslint-disable-next-line no-console
    console.warn(
      "[Feedback Management System] NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY " +
        "are not set. Copy .env.local.example to .env.local and add your Supabase project " +
        "credentials — until then, every Supabase-backed page will show its error state."
    );
  }

  return {
    url: url || "https://placeholder-project.supabase.co",
    anonKey: anonKey || "placeholder-anon-key",
    isConfigured,
  };
}
