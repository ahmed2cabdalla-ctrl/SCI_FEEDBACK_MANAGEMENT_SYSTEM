import "server-only";
import { createServerSupabaseClient } from "./server";

/**
 * Verifies the caller has a valid Supabase session. Airtable has no
 * row-level security of its own, so every API route under src/app/api/**
 * that touches Airtable must call this first — it's the only gate between
 * an anonymous request and the organisation's feedback data.
 */
export async function requireUser() {
  const supabase = createServerSupabaseClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user;
}
