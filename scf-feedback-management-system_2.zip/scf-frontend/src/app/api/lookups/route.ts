import { NextResponse } from "next/server";
import { requireUser } from "@/lib/supabase/requireUser";
import { listAllRecords, AirtableNotConfiguredError } from "@/lib/airtable/client";
import { mapNamedRecordToOption } from "@/lib/airtable/mappers";
import { TABLES } from "@/lib/airtable/tables";

export const dynamic = "force-dynamic";

/** Reference dropdown data (sectors/projects/locations) for create/edit forms. */
export async function GET() {
  const user = await requireUser();
  if (!user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  try {
    const [sectors, projects, locations] = await Promise.all([
      listAllRecords<{ Name?: string }>(TABLES.SECTORS),
      listAllRecords<{ Name?: string }>(TABLES.PROJECTS),
      listAllRecords<{ Name?: string }>(TABLES.LOCATIONS),
    ]);

    return NextResponse.json({
      sectors: sectors.map(mapNamedRecordToOption),
      projects: projects.map(mapNamedRecordToOption),
      locations: locations.map(mapNamedRecordToOption),
    });
  } catch (err) {
    const message =
      err instanceof AirtableNotConfiguredError
        ? err.message
        : err instanceof Error
          ? err.message
          : "Could not load reference data from Airtable.";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
