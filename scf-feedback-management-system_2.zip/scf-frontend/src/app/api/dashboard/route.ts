import { NextResponse } from "next/server";
import { requireUser } from "@/lib/supabase/requireUser";
import { listAllRecords, AirtableNotConfiguredError } from "@/lib/airtable/client";
import { mapFeedbackRecord, type AirtableFeedbackFields } from "@/lib/airtable/mappers";
import { TABLES } from "@/lib/airtable/tables";
import { STATUS_LABELS } from "@/lib/constants/labels";
import { formatShortDay, lastNDaysISO } from "@/lib/utils/date";
import type { CategoryCount, DashboardStats, StatusCount, TrendPoint } from "@/types";
import type { FeedbackStatus } from "@/types/feedback";

export const dynamic = "force-dynamic";

const TREND_WINDOW_DAYS = 14;
const RECENT_LIMIT = 8;

/**
 * Loads everything the dashboard overview needs. Airtable has no
 * server-side aggregation (no SQL COUNT/GROUP BY), so — unlike a Postgres
 * backend — this fetches every Feedback record once and computes stats,
 * the trend line, and the category/status breakdowns here in the route
 * handler. Fine at the record volumes Airtable itself supports; if your
 * base grows very large this endpoint's latency will grow with it.
 */
export async function GET() {
  const user = await requireUser();
  if (!user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  try {
    const records = await listAllRecords<AirtableFeedbackFields>(TABLES.FEEDBACK);
    const rows = records.map(mapFeedbackRecord);

    const totalFeedback = rows.length;
    const countBy = (status: FeedbackStatus) => rows.filter((r) => r.status === status).length;

    const newCount = countBy("new");
    const inProgressCount = countBy("in_progress");
    const resolvedCount = countBy("resolved") + countBy("closed");
    const escalatedCount = countBy("escalated");
    const sensitiveCount = rows.filter((r) => r.sensitivity === "sensitive").length;
    const resolutionRate = totalFeedback ? Math.round((resolvedCount / totalFeedback) * 100) : 0;

    const stats: DashboardStats = {
      totalFeedback,
      newCount,
      inProgressCount,
      resolvedCount,
      escalatedCount,
      sensitiveCount,
      resolutionRate,
    };

    const byStatus: StatusCount[] = (
      ["new", "in_progress", "resolved", "closed", "escalated"] as FeedbackStatus[]
    ).map((status) => ({ status, label: STATUS_LABELS[status], value: countBy(status) }));

    const since = lastNDaysISO(TREND_WINDOW_DAYS)[0];
    const windowRows = rows.filter((r) => r.createdAt.slice(0, 10) >= since);

    const days = lastNDaysISO(TREND_WINDOW_DAYS);
    const trend: TrendPoint[] = days.map((day) => ({
      date: day,
      label: formatShortDay(day),
      total: windowRows.filter((r) => r.createdAt.slice(0, 10) === day).length,
    }));

    const categoryTally = new Map<string, number>();
    for (const row of windowRows) {
      const key = row.category ?? "Uncategorised";
      categoryTally.set(key, (categoryTally.get(key) ?? 0) + 1);
    }
    const byCategory: CategoryCount[] = Array.from(categoryTally.entries())
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);

    const recent = [...rows]
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, RECENT_LIMIT);

    return NextResponse.json({ stats, trend, byCategory, byStatus, recent });
  } catch (err) {
    const message =
      err instanceof AirtableNotConfiguredError
        ? err.message
        : err instanceof Error
          ? err.message
          : "Could not load dashboard data from Airtable.";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
