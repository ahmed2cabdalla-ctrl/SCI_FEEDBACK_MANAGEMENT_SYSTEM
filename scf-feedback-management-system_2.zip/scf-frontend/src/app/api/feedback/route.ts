import { NextResponse, type NextRequest } from "next/server";
import { requireUser } from "@/lib/supabase/requireUser";
import { createRecord, listAllRecords, AirtableNotConfiguredError } from "@/lib/airtable/client";
import { mapFeedbackRecord, type AirtableFeedbackFields } from "@/lib/airtable/mappers";
import { FEEDBACK_FIELDS, TABLES } from "@/lib/airtable/tables";
import {
  CHANNEL_LABELS,
  PRIORITY_LABELS,
  SENSITIVITY_LABELS,
  STATUS_LABELS,
  TYPE_LABELS,
} from "@/lib/constants/labels";
import type {
  FeedbackChannel,
  FeedbackPriority,
  FeedbackSensitivity,
  FeedbackType,
} from "@/types/feedback";

export const dynamic = "force-dynamic";

const LIST_LIMIT = 200;

function airtableErrorResponse(err: unknown) {
  const message =
    err instanceof AirtableNotConfiguredError
      ? err.message
      : err instanceof Error
        ? err.message
        : "Could not reach Airtable.";
  return NextResponse.json({ error: message }, { status: 502 });
}

function generateReferenceCode() {
  return `FB-${Date.now().toString(36).toUpperCase()}`;
}

/** Recent feedback records (joined with sector/project/location names via Airtable lookup fields). */
export async function GET() {
  const user = await requireUser();
  if (!user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  try {
    const records = await listAllRecords<AirtableFeedbackFields>(TABLES.FEEDBACK);
    const rows = records
      .map(mapFeedbackRecord)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, LIST_LIMIT);

    return NextResponse.json({ rows });
  } catch (err) {
    return airtableErrorResponse(err);
  }
}

interface NewFeedbackBody {
  type: FeedbackType;
  channel: FeedbackChannel;
  priority: FeedbackPriority;
  sensitivity: FeedbackSensitivity;
  category?: string;
  sectorId?: string;
  projectId?: string;
  locationId?: string;
  description: string;
  isAnonymous: boolean;
}

/** Creates a new feedback record from the "Log new feedback" form. */
export async function POST(request: NextRequest) {
  const user = await requireUser();
  if (!user) {
    return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  }

  let body: NewFeedbackBody;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  if (!body.description?.trim()) {
    return NextResponse.json({ error: "Description is required." }, { status: 400 });
  }

  const fields: Partial<AirtableFeedbackFields> = {
    [FEEDBACK_FIELDS.REFERENCE_CODE]: generateReferenceCode(),
    [FEEDBACK_FIELDS.TYPE]: TYPE_LABELS[body.type],
    [FEEDBACK_FIELDS.CHANNEL]: CHANNEL_LABELS[body.channel],
    [FEEDBACK_FIELDS.PRIORITY]: PRIORITY_LABELS[body.priority],
    [FEEDBACK_FIELDS.SENSITIVITY]: SENSITIVITY_LABELS[body.sensitivity],
    [FEEDBACK_FIELDS.STATUS]: STATUS_LABELS.new,
    [FEEDBACK_FIELDS.CATEGORY]: body.category || undefined,
    [FEEDBACK_FIELDS.SECTOR]: body.sectorId ? [body.sectorId] : undefined,
    [FEEDBACK_FIELDS.PROJECT]: body.projectId ? [body.projectId] : undefined,
    [FEEDBACK_FIELDS.LOCATION]: body.locationId ? [body.locationId] : undefined,
    [FEEDBACK_FIELDS.DESCRIPTION]: body.description.trim(),
    [FEEDBACK_FIELDS.IS_ANONYMOUS]: body.isAnonymous,
    [FEEDBACK_FIELDS.SUBMITTED_BY]: user.email ?? user.id,
  };

  try {
    const record = await createRecord<AirtableFeedbackFields>(TABLES.FEEDBACK, fields);
    return NextResponse.json({ row: mapFeedbackRecord(record) }, { status: 201 });
  } catch (err) {
    return airtableErrorResponse(err);
  }
}
