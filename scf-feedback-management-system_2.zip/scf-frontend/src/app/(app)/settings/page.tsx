import { Settings } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function SettingsPage() {
  return (
    <ModulePlaceholder
      icon={Settings}
      title="Settings"
      description="Organisation-wide configuration: feedback categories, response-time targets, notification preferences and branding."
      plannedFeatures={[
        "Manage feedback categories and priority SLAs",
        "Notification preferences",
        "Branding (logo, organisation name) once official assets are supplied",
      ]}
    />
  );
}
