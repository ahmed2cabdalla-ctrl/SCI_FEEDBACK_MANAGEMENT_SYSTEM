import { FolderKanban } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function ProjectsPage() {
  return (
    <ModulePlaceholder
      icon={FolderKanban}
      title="Projects"
      description="Track active and closed projects, each linked to a sector and one or more locations, to scope feedback and reporting."
      plannedFeatures={[
        "Project list with status, sector and location (DataTable + FilterBar)",
        "Create / edit project (Modal + form fields)",
        "Project detail with feedback volume and resolution rate",
      ]}
    />
  );
}
