"use client";

import { RefreshCw } from "lucide-react";
import { useDashboardData } from "@/hooks/useDashboardData";
import { StatsOverview } from "@/components/dashboard/StatsOverview";
import { FeedbackTrendChart } from "@/components/dashboard/FeedbackTrendChart";
import { CategoryBreakdownChart } from "@/components/dashboard/CategoryBreakdownChart";
import { StatusDistributionChart } from "@/components/dashboard/StatusDistributionChart";
import { RecentFeedbackTable } from "@/components/dashboard/RecentFeedbackTable";
import { Button, Card, EmptyState, ErrorState, LoadingState } from "@/components/ui";

export default function DashboardPage() {
  const { status, data, error, reload } = useDashboardData();

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-ink-muted">
          Overview of community feedback across all sectors and projects.
        </p>
        <Button variant="outline" size="sm" onClick={reload}>
          <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
          Refresh
        </Button>
      </div>

      {status === "loading" ? (
        <Card>
          <LoadingState label="Loading dashboard data from Supabase…" />
        </Card>
      ) : null}

      {status === "error" ? (
        <Card>
          <ErrorState
            title="Couldn't load dashboard data"
            description={error ?? "Check your Supabase connection and table permissions, then try again."}
            onRetry={reload}
          />
        </Card>
      ) : null}

      {status === "empty" ? (
        <Card>
          <EmptyState
            title="No feedback recorded yet"
            description="Once feedback starts coming in through the hotline, suggestion boxes or field teams, your dashboard metrics will appear here."
          />
        </Card>
      ) : null}

      {status === "success" && data ? (
        <>
          <StatsOverview stats={data.stats} />

          <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div className="xl:col-span-2">
              <FeedbackTrendChart data={data.trend} />
            </div>
            <StatusDistributionChart data={data.byStatus} />
          </div>

          <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div className="xl:col-span-1">
              <CategoryBreakdownChart data={data.byCategory} />
            </div>
            <div className="xl:col-span-2">
              <Card className="p-5">
                <RecentFeedbackTable rows={data.recent} />
              </Card>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
