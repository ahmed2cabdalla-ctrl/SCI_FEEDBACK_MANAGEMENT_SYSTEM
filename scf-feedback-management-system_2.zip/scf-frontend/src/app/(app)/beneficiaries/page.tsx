import { Users } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function BeneficiariesPage() {
  return (
    <ModulePlaceholder
      icon={Users}
      title="Beneficiaries"
      description="Register and look up beneficiaries linked to feedback, with privacy-conscious, minimal-data profiles."
      plannedFeatures={[
        "Searchable, filterable beneficiary directory (DataTable + FilterBar)",
        "Beneficiary profile with related feedback history",
        "Add / edit beneficiary via the shared Modal + form fields",
        "Role-based visibility for sensitive identifying fields",
      ]}
    />
  );
}
