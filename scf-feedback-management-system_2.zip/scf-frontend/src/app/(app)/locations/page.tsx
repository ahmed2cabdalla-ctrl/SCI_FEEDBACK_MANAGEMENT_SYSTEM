import { MapPin } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function LocationsPage() {
  return (
    <ModulePlaceholder
      icon={MapPin}
      title="Locations"
      description="Maintain the country / region / district / community hierarchy used to geo-tag beneficiaries, projects and feedback."
      plannedFeatures={[
        "Hierarchical location browser (country → region → district → community)",
        "Create / edit location (Modal + form fields)",
        "Feedback heat-map by location",
      ]}
    />
  );
}
