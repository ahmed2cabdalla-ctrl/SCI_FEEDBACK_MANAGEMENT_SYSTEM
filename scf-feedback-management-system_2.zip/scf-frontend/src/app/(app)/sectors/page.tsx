import { LayoutGrid } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function SectorsPage() {
  return (
    <ModulePlaceholder
      icon={LayoutGrid}
      title="Sectors"
      description="Manage the response sectors (e.g. Education, Health, Child Protection, WASH) used to categorise feedback and projects."
      plannedFeatures={[
        "List of sectors with open feedback counts (DataTable)",
        "Create / rename / archive a sector (Modal + form fields)",
        "Sector detail view with linked projects and trend chart",
      ]}
    />
  );
}
