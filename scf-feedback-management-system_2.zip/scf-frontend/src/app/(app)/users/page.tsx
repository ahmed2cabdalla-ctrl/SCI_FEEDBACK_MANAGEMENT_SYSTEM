import { UserCog } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function UsersPage() {
  return (
    <ModulePlaceholder
      icon={UserCog}
      title="Users"
      description="Administer staff accounts and roles (Admin, Accountability Officer, Program Staff, Viewer) that control access across the system."
      plannedFeatures={[
        "User list with role and active status (DataTable + FilterBar)",
        "Invite / deactivate a user, change role (Modal + form fields)",
        "Enforced via Supabase Row Level Security, not just the UI",
      ]}
    />
  );
}
