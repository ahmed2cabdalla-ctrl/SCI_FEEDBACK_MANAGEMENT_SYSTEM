import { redirect } from "next/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { DashboardShell } from "@/components/layout/DashboardShell";

/**
 * Shared layout for every authenticated route (/dashboard, /feedback, ...).
 * Verifies the session server-side (belt-and-braces alongside middleware.ts)
 * before rendering the sidebar/top-nav shell.
 */
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = createServerSupabaseClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  return <DashboardShell>{children}</DashboardShell>;
}
