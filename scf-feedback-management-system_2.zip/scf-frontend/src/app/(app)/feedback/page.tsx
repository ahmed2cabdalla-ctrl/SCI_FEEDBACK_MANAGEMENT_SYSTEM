"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";
import { useFeedbackList } from "@/hooks/useFeedbackList";
import { Button, ErrorState } from "@/components/ui";
import { PriorityBadge, StatusBadge } from "@/components/ui/Badge";
import { DataTable, type Column } from "@/components/ui/Table";
import { FilterBar } from "@/components/ui/FilterBar";
import { CHANNEL_LABELS, STATUS_LABELS, TYPE_LABELS, PRIORITY_LABELS } from "@/lib/constants/labels";
import { formatDateTime } from "@/lib/utils/date";
import type { FeedbackRecord } from "@/types";

const STATUS_OPTIONS = Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label }));
const PRIORITY_OPTIONS = Object.entries(PRIORITY_LABELS).map(([value, label]) => ({ value, label }));
const TYPE_OPTIONS = Object.entries(TYPE_LABELS).map(([value, label]) => ({ value, label }));

export default function FeedbackPage() {
  const { status, data, error, reload } = useFeedbackList();
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<Record<string, string>>({});

  const filteredRows = useMemo(() => {
    const rows = data ?? [];
    return rows.filter((r) => {
      if (filters.status && filters.status !== "all" && r.status !== filters.status) return false;
      if (filters.priority && filters.priority !== "all" && r.priority !== filters.priority)
        return false;
      if (filters.type && filters.type !== "all" && r.type !== filters.type) return false;
      if (search) {
        const q = search.toLowerCase();
        const haystack = `${r.referenceCode} ${r.description} ${r.category ?? ""}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [data, filters, search]);

  const columns: Column<FeedbackRecord>[] = [
    {
      key: "reference",
      header: "Reference",
      render: (r) => (
        <div>
          <p className="font-medium text-ink">{r.referenceCode}</p>
          <p className="text-xs text-ink-faint">{TYPE_LABELS[r.type]}</p>
        </div>
      ),
    },
    {
      key: "description",
      header: "Summary",
      render: (r) => <span className="line-clamp-1 max-w-sm text-ink-muted">{r.description}</span>,
    },
    {
      key: "location",
      header: "Location",
      render: (r) => <span className="text-ink-muted">{r.locationName ?? "—"}</span>,
      hideOnMobile: true,
    },
    {
      key: "channel",
      header: "Channel",
      render: (r) => <span className="text-ink-muted">{CHANNEL_LABELS[r.channel]}</span>,
      hideOnMobile: true,
    },
    { key: "priority", header: "Priority", render: (r) => <PriorityBadge priority={r.priority} /> },
    { key: "status", header: "Status", render: (r) => <StatusBadge status={r.status} /> },
    {
      key: "created",
      header: "Received",
      render: (r) => <span className="text-ink-muted">{formatDateTime(r.createdAt)}</span>,
      hideOnMobile: true,
    },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-ink-muted">
          {status === "success"
            ? `${filteredRows.length} of ${data?.length ?? 0} records`
            : "All feedback records"}
        </p>
        <Link href="/feedback/new">
          <Button size="sm">
            <Plus className="h-4 w-4" aria-hidden="true" />
            New feedback
          </Button>
        </Link>
      </div>

      {status !== "error" ? (
        <FilterBar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by reference, category or keyword…"
          filters={[
            { key: "status", label: "Statuses", options: STATUS_OPTIONS },
            { key: "priority", label: "Priorities", options: PRIORITY_OPTIONS },
            { key: "type", label: "Types", options: TYPE_OPTIONS },
          ]}
          activeValues={filters}
          onFilterChange={(key, value) => setFilters((f) => ({ ...f, [key]: value }))}
          onClear={() => {
            setSearch("");
            setFilters({});
          }}
        />
      ) : null}

      {status === "error" ? (
        <div className="rounded-xl border border-gray-200 bg-white">
          <ErrorState description={error ?? undefined} onRetry={reload} />
        </div>
      ) : (
        <DataTable
          columns={columns}
          rows={filteredRows}
          rowKey={(r) => r.id}
          status={status === "loading" ? "loading" : "success"}
          emptyTitle="No feedback matches your filters"
          emptyDescription="Try clearing the search or filters above, or log a new feedback record."
        />
      )}
    </div>
  );
}
