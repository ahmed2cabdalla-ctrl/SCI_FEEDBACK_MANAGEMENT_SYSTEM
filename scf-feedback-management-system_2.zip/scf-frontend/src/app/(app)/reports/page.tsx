import { BarChart3 } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function ReportsPage() {
  return (
    <ModulePlaceholder
      icon={BarChart3}
      title="Reports"
      description="Generate accountability reports for donors, management and safeguarding review — filterable by date range, sector, project and location."
      plannedFeatures={[
        "Custom date-range and multi-filter report builder (FilterBar)",
        "Exportable summary tables and charts (reusing dashboard chart components)",
        "Scheduled/recurring report exports",
      ]}
    />
  );
}
