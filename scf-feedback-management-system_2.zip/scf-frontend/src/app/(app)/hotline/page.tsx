import { PhoneCall } from "lucide-react";
import { ModulePlaceholder } from "@/components/layout/ModulePlaceholder";

export default function HotlinePage() {
  return (
    <ModulePlaceholder
      icon={PhoneCall}
      title="Hotline"
      description="Log and triage calls coming through the community hotline, and link them to a feedback record."
      plannedFeatures={[
        "Call log with duration, handler and linked feedback (DataTable + FilterBar)",
        "Log a new call (Modal + form fields) with option to raise feedback directly",
        "Daily / weekly call volume chart",
      ]}
    />
  );
}
