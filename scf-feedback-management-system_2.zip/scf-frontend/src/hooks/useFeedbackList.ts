"use client";

import { useCallback, useEffect, useState } from "react";
import type { AsyncState, FeedbackRecord } from "@/types";

/** Loads feedback records from /api/feedback (backed by Airtable) for the Feedback list page. */
export function useFeedbackList() {
  const [state, setState] = useState<AsyncState<FeedbackRecord[]>>({
    status: "loading",
    data: null,
    error: null,
  });
  const [reloadToken, setReloadToken] = useState(0);
  const reload = useCallback(() => setReloadToken((t) => t + 1), []);

  useEffect(() => {
    let isMounted = true;

    async function load() {
      setState({ status: "loading", data: null, error: null });
      try {
        const res = await fetch("/api/feedback");
        const json = await res.json();
        if (!res.ok) throw new Error(json.error ?? "Could not load feedback.");
        if (!isMounted) return;

        const rows: FeedbackRecord[] = json.rows;
        setState({ status: rows.length ? "success" : "empty", data: rows, error: null } as AsyncState<
          FeedbackRecord[]
        >);
      } catch (err) {
        if (!isMounted) return;
        setState({
          status: "error",
          data: null,
          error: err instanceof Error ? err.message : "Could not load feedback.",
        });
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, [reloadToken]);

  return { ...state, reload };
}
