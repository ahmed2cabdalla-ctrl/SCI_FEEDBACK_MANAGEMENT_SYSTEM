"use client";

import { useCallback, useEffect, useState } from "react";
import type { AsyncState, CategoryCount, DashboardStats, FeedbackRecord, StatusCount, TrendPoint } from "@/types";

interface DashboardData {
  stats: DashboardStats;
  trend: TrendPoint[];
  byCategory: CategoryCount[];
  byStatus: StatusCount[];
  recent: FeedbackRecord[];
}

/**
 * Loads the dashboard overview from /api/dashboard, which reads from
 * Airtable server-side (see src/app/api/dashboard/route.ts) — nothing here
 * is mocked. Kept as a hook (rather than a Server Component fetch) so the
 * page can offer a manual "Refresh" action and its own loading state.
 */
export function useDashboardData() {
  const [state, setState] = useState<AsyncState<DashboardData>>({
    status: "loading",
    data: null,
    error: null,
  });
  const [reloadToken, setReloadToken] = useState(0);
  const reload = useCallback(() => setReloadToken((t) => t + 1), []);

  useEffect(() => {
    let isMounted = true;

    async function load() {
      setState({ status: "loading", data: null, error: null });
      try {
        const res = await fetch("/api/dashboard");
        const json = await res.json();
        if (!res.ok) throw new Error(json.error ?? "Could not load dashboard data.");
        if (!isMounted) return;

        const data: DashboardData = json;
        const isEmpty = data.stats.totalFeedback === 0;
        setState({ status: isEmpty ? "empty" : "success", data, error: null } as AsyncState<DashboardData>);
      } catch (err) {
        if (!isMounted) return;
        setState({
          status: "error",
          data: null,
          error: err instanceof Error ? err.message : "Could not load dashboard data.",
        });
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, [reloadToken]);

  return { ...state, reload };
}
