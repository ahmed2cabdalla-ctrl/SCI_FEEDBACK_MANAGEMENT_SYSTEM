"use client";

import { useEffect, useState } from "react";
import type { SelectOption } from "@/types";

interface Lookups {
  sectors: SelectOption[];
  projects: SelectOption[];
  locations: SelectOption[];
}

/** Loads the reference dropdown data (sectors/projects/locations) from /api/lookups (Airtable). */
export function useLookups() {
  const [lookups, setLookups] = useState<Lookups>({ sectors: [], projects: [], locations: [] });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    async function load() {
      setIsLoading(true);
      setError(null);
      try {
        const res = await fetch("/api/lookups");
        const json = await res.json();
        if (!res.ok) throw new Error(json.error ?? "Could not load reference data.");
        if (!isMounted) return;
        setLookups({ sectors: json.sectors, projects: json.projects, locations: json.locations });
      } catch (err) {
        if (!isMounted) return;
        setError(err instanceof Error ? err.message : "Could not load reference data.");
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, []);

  return { ...lookups, isLoading, error };
}
