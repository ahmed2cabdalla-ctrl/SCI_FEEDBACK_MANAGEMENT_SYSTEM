export * from "./database";

import type {
  FeedbackChannel,
  FeedbackPriority,
  FeedbackSensitivity,
  FeedbackStatus,
  FeedbackType,
} from "./database";

/** Row shape used across dashboard widgets and tables (joined, denormalised for display). */
export interface FeedbackRecord {
  id: string;
  referenceCode: string;
  type: FeedbackType;
  category: string | null;
  channel: FeedbackChannel;
  sensitivity: FeedbackSensitivity;
  priority: FeedbackPriority;
  status: FeedbackStatus;
  isAnonymous: boolean;
  description: string;
  sectorName: string | null;
  projectName: string | null;
  locationName: string | null;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
}

export interface DashboardStats {
  totalFeedback: number;
  newCount: number;
  inProgressCount: number;
  resolvedCount: number;
  escalatedCount: number;
  sensitiveCount: number;
  resolutionRate: number; // 0-100
}

export interface TrendPoint {
  date: string; // ISO date (day)
  label: string; // display label, e.g. "Sep 03"
  total: number;
}

export interface CategoryCount {
  name: string;
  value: number;
}

export interface StatusCount {
  status: FeedbackStatus;
  label: string;
  value: number;
}

/** Generic async data state used by data-fetching hooks throughout the app. */
export type AsyncState<T> =
  | { status: "loading"; data: null; error: null }
  | { status: "error"; data: null; error: string }
  | { status: "empty"; data: T; error: null }
  | { status: "success"; data: T; error: null };

export interface NavItem {
  label: string;
  href: string;
  icon: keyof typeof import("lucide-react");
}

export interface SelectOption {
  label: string;
  value: string;
}

/**
 * Shape of a `feedback` row selected together with its related
 * sector/project/location names, e.g.:
 *
 *   .select(`*, sectors ( name ), projects ( name ), locations ( name )`)
 *
 * Supabase's generated types would express this precisely once the real
 * foreign keys are known; until then this is cast at the query boundary
 * (see src/lib/supabase/mappers.ts) so the rest of the app works with a
 * clean, explicit shape instead of `any`.
 */
export interface JoinedFeedbackRow {
  id: string;
  reference_code: string;
  type: import("./database").FeedbackType;
  category: string | null;
  channel: import("./database").FeedbackChannel;
  sensitivity: import("./database").FeedbackSensitivity;
  priority: import("./database").FeedbackPriority;
  status: import("./database").FeedbackStatus;
  is_anonymous: boolean;
  description: string;
  created_at: string;
  updated_at: string;
  resolved_at: string | null;
  sectors: { name: string } | null;
  projects: { name: string } | null;
  locations: { name: string } | null;
}
