/**
 * Hand-written Supabase schema types.
 *
 * IMPORTANT: This file describes the schema the rest of the app assumes
 * (see /supabase/schema.sql for the matching reference SQL). It is a
 * starting point, not a source of truth. Once your real Supabase project
 * is in place, regenerate this file from it so the types can never drift
 * from the database:
 *
 *   npx supabase gen types typescript --project-id <your-project-ref> > src/types/database.ts
 *
 * If your table/column names differ, either rename them to match this
 * file or update the queries in src/hooks and src/app to match your names.
 */

export type FeedbackType = "complaint" | "compliment" | "suggestion" | "inquiry";

export type FeedbackChannel =
  | "hotline"
  | "in_person"
  | "suggestion_box"
  | "sms"
  | "email"
  | "community_meeting"
  | "other";

export type FeedbackSensitivity = "sensitive" | "non_sensitive";

export type FeedbackPriority = "low" | "medium" | "high" | "critical";

export type FeedbackStatus = "new" | "in_progress" | "resolved" | "closed" | "escalated";

export type UserRole = "admin" | "accountability_officer" | "program_staff" | "viewer";

// ---------------------------------------------------------------------------
// Standalone row shapes (defined first, then wired into Database below) —
// keeping these separate from the Database interface avoids the self
// referential `Database["public"]["Tables"][...]` lookups that confuse
// TypeScript's inference for `.insert()` / `.update()` calls.
// ---------------------------------------------------------------------------

export type ProfileRow = {
  id: string;
  full_name: string;
  role: UserRole;
  avatar_url: string | null;
  location_id: string | null;
  is_active: boolean;
  created_at: string;
}

export type SectorRow = {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

export type LocationRow = {
  id: string;
  name: string;
  type: "country" | "region" | "district" | "community";
  parent_id: string | null;
  created_at: string;
}

export type ProjectRow = {
  id: string;
  name: string;
  code: string | null;
  sector_id: string | null;
  location_id: string | null;
  status: "planned" | "active" | "closed";
  created_at: string;
}

export type BeneficiaryRow = {
  id: string;
  unique_code: string;
  full_name: string | null;
  gender: "female" | "male" | "other" | "unspecified" | null;
  age_group: "child" | "youth" | "adult" | "elderly" | null;
  location_id: string | null;
  project_id: string | null;
  contact_phone: string | null;
  created_at: string;
}

export type FeedbackRow = {
  id: string;
  reference_code: string;
  type: FeedbackType;
  category: string | null;
  sector_id: string | null;
  project_id: string | null;
  location_id: string | null;
  beneficiary_id: string | null;
  channel: FeedbackChannel;
  sensitivity: FeedbackSensitivity;
  priority: FeedbackPriority;
  status: FeedbackStatus;
  is_anonymous: boolean;
  description: string;
  response: string | null;
  submitted_by: string | null;
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
  resolved_at: string | null;
}

export type HotlineCallRow = {
  id: string;
  caller_reference: string | null;
  call_type: "inbound" | "outbound";
  duration_seconds: number | null;
  feedback_id: string | null;
  handled_by: string | null;
  notes: string | null;
  created_at: string;
}

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: ProfileRow;
        Insert: Partial<ProfileRow> & Pick<ProfileRow, "id" | "full_name" | "role">;
        Update: Partial<ProfileRow>;
        Relationships: [];
      };
      sectors: {
        Row: SectorRow;
        Insert: Partial<SectorRow> & Pick<SectorRow, "name">;
        Update: Partial<SectorRow>;
        Relationships: [];
      };
      locations: {
        Row: LocationRow;
        Insert: Partial<LocationRow> & Pick<LocationRow, "name" | "type">;
        Update: Partial<LocationRow>;
        Relationships: [];
      };
      projects: {
        Row: ProjectRow;
        Insert: Partial<ProjectRow> & Pick<ProjectRow, "name">;
        Update: Partial<ProjectRow>;
        Relationships: [];
      };
      beneficiaries: {
        Row: BeneficiaryRow;
        Insert: Partial<BeneficiaryRow> & Pick<BeneficiaryRow, "unique_code">;
        Update: Partial<BeneficiaryRow>;
        Relationships: [];
      };
      feedback: {
        Row: FeedbackRow;
        Insert: Partial<FeedbackRow> &
          Pick<FeedbackRow, "reference_code" | "type" | "channel" | "description">;
        Update: Partial<FeedbackRow>;
        Relationships: [];
      };
      hotline_calls: {
        Row: HotlineCallRow;
        Insert: Partial<HotlineCallRow> & Pick<HotlineCallRow, "call_type">;
        Update: Partial<HotlineCallRow>;
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
  };
}
