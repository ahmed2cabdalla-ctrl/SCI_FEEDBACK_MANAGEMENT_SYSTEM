"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import type { SelectOption } from "@/types";

interface Lookups {
  sectors: SelectOption[];
  projects: SelectOption[];
  locations: SelectOption[];
}

/** Loads the reference dropdown data (sectors/projects/locations) used by create/edit forms. */
export function useLookups() {
  const [lookups, setLookups] = useState<Lookups>({ sectors: [], projects: [], locations: [] });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    const supabase = createClient();

    async function load() {
      setIsLoading(true);
      setError(null);
      try {
        const [sectors, projects, locations] = await Promise.all([
          supabase.from("sectors").select("id, name").order("name"),
          supabase.from("projects").select("id, name").order("name"),
          supabase.from("locations").select("id, name").order("name"),
        ]);

        if (sectors.error) throw sectors.error;
        if (projects.error) throw projects.error;
        if (locations.error) throw locations.error;

        if (!isMounted) return;
        setLookups({
          sectors: (sectors.data ?? []).map((s) => ({ label: s.name, value: s.id })),
          projects: (projects.data ?? []).map((p) => ({ label: p.name, value: p.id })),
          locations: (locations.data ?? []).map((l) => ({ label: l.name, value: l.id })),
        });
      } catch (err) {
        if (!isMounted) return;
        setError(err instanceof Error ? err.message : "Could not load reference data.");
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, []);

  return { ...lookups, isLoading, error };
}
