"use client";

import { useEffect, useState, useCallback } from "react";
import { createClient } from "@/lib/supabase/client";
import { mapFeedbackRow } from "@/lib/supabase/mappers";
import type { AsyncState, FeedbackRecord, JoinedFeedbackRow } from "@/types";

const LIST_LIMIT = 100;

/**
 * Loads recent feedback records (joined with sector/project/location names)
 * for the Feedback list page. Filtering/search happens client-side over
 * this window; swap to server-side filtering once volumes grow.
 */
export function useFeedbackList() {
  const [state, setState] = useState<AsyncState<FeedbackRecord[]>>({
    status: "loading",
    data: null,
    error: null,
  });
  const [reloadToken, setReloadToken] = useState(0);
  const reload = useCallback(() => setReloadToken((t) => t + 1), []);

  useEffect(() => {
    let isMounted = true;
    const supabase = createClient();

    async function load() {
      setState({ status: "loading", data: null, error: null });
      try {
        const { data, error } = await supabase
          .from("feedback")
          .select(
            `id, reference_code, type, category, channel, sensitivity, priority, status,
             is_anonymous, description, created_at, updated_at, resolved_at,
             sectors ( name ), projects ( name ), locations ( name )`
          )
          .order("created_at", { ascending: false })
          .limit(LIST_LIMIT);

        if (error) throw error;
        if (!isMounted) return;

        const rows: FeedbackRecord[] = ((data ?? []) as unknown as JoinedFeedbackRow[]).map(
          mapFeedbackRow
        );

        setState({
          status: rows.length ? "success" : "empty",
          data: rows,
          error: null,
        } as AsyncState<FeedbackRecord[]>);
      } catch (err) {
        if (!isMounted) return;
        setState({
          status: "error",
          data: null,
          error: err instanceof Error ? err.message : "Could not load feedback from Supabase.",
        });
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, [reloadToken]);

  return { ...state, reload };
}
