"use client";

import { useCallback, useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { lastNDaysISO, formatShortDay } from "@/lib/utils/date";
import type {
  AsyncState,
  CategoryCount,
  DashboardStats,
  FeedbackRecord,
  JoinedFeedbackRow,
  StatusCount,
  TrendPoint,
} from "@/types";
import type { FeedbackStatus } from "@/types/database";
import { STATUS_LABELS } from "@/lib/constants/labels";
import { mapFeedbackRow } from "@/lib/supabase/mappers";

interface DashboardData {
  stats: DashboardStats;
  trend: TrendPoint[];
  byCategory: CategoryCount[];
  byStatus: StatusCount[];
  recent: FeedbackRecord[];
}

const TREND_WINDOW_DAYS = 14;
const RECENT_LIMIT = 8;

/**
 * Loads everything the dashboard overview needs from Supabase:
 * headline stats, a trend line, a category breakdown, a status
 * breakdown, and the most recent feedback entries.
 *
 * All of this reads from the real `feedback` table (see
 * /supabase/schema.sql) — nothing here is mocked. If your schema uses
 * different table/column names, update the `.from()` / `.select()`
 * calls below to match.
 */
export function useDashboardData() {
  const [state, setState] = useState<AsyncState<DashboardData>>({
    status: "loading",
    data: null,
    error: null,
  });
  const [reloadToken, setReloadToken] = useState(0);

  const reload = useCallback(() => setReloadToken((t) => t + 1), []);

  useEffect(() => {
    let isMounted = true;
    const supabase = createClient();

    async function load() {
      setState({ status: "loading", data: null, error: null });

      try {
        const since = lastNDaysISO(TREND_WINDOW_DAYS)[0];

        const [countsRes, windowRes, recentRes] = await Promise.all([
          supabase.from("feedback").select("status", { count: "exact" }),
          supabase
            .from("feedback")
            .select("id, status, category, created_at")
            .gte("created_at", since),
          supabase
            .from("feedback")
            .select(
              `id, reference_code, type, category, channel, sensitivity, priority, status,
               is_anonymous, description, created_at, updated_at, resolved_at,
               sectors ( name ), projects ( name ), locations ( name )`
            )
            .order("created_at", { ascending: false })
            .limit(RECENT_LIMIT),
        ]);

        if (countsRes.error) throw countsRes.error;
        if (windowRes.error) throw windowRes.error;
        if (recentRes.error) throw recentRes.error;

        const allStatuses = (countsRes.data ?? []) as { status: FeedbackStatus }[];
        const totalFeedback = countsRes.count ?? allStatuses.length;

        const countBy = (status: FeedbackStatus) =>
          allStatuses.filter((r) => r.status === status).length;

        const newCount = countBy("new");
        const inProgressCount = countBy("in_progress");
        const resolvedCount = countBy("resolved");
        const closedCount = countBy("closed");
        const escalatedCount = countBy("escalated");
        const sensitiveCount = allStatuses.length
          ? await countSensitive(supabase)
          : 0;

        const resolutionRate = totalFeedback
          ? Math.round(((resolvedCount + closedCount) / totalFeedback) * 100)
          : 0;

        const stats: DashboardStats = {
          totalFeedback,
          newCount,
          inProgressCount,
          resolvedCount: resolvedCount + closedCount,
          escalatedCount,
          sensitiveCount,
          resolutionRate,
        };

        const byStatus: StatusCount[] = (
          ["new", "in_progress", "resolved", "closed", "escalated"] as FeedbackStatus[]
        ).map((status) => ({
          status,
          label: STATUS_LABELS[status],
          value: countBy(status),
        }));

        const windowRows = (windowRes.data ?? []) as {
          created_at: string;
          category: string | null;
        }[];

        const days = lastNDaysISO(TREND_WINDOW_DAYS);
        const trend: TrendPoint[] = days.map((day) => ({
          date: day,
          label: formatShortDay(day),
          total: windowRows.filter((r) => r.created_at.slice(0, 10) === day).length,
        }));

        const categoryTally = new Map<string, number>();
        for (const row of windowRows) {
          const key = row.category ?? "Uncategorised";
          categoryTally.set(key, (categoryTally.get(key) ?? 0) + 1);
        }
        const byCategory: CategoryCount[] = Array.from(categoryTally.entries())
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value)
          .slice(0, 6);

        const recent: FeedbackRecord[] = ((recentRes.data ?? []) as unknown as JoinedFeedbackRow[]).map(
          mapFeedbackRow
        );

        if (!isMounted) return;

        const data: DashboardData = { stats, trend, byCategory, byStatus, recent };
        const isEmpty = totalFeedback === 0;
        setState({ status: isEmpty ? "empty" : "success", data, error: null } as AsyncState<DashboardData>);
      } catch (err) {
        if (!isMounted) return;
        const message =
          err instanceof Error ? err.message : "Could not load dashboard data from Supabase.";
        setState({ status: "error", data: null, error: message });
      }
    }

    load();
    return () => {
      isMounted = false;
    };
  }, [reloadToken]);

  return { ...state, reload };
}

async function countSensitive(supabase: ReturnType<typeof createClient>) {
  const { count, error } = await supabase
    .from("feedback")
    .select("id", { count: "exact", head: true })
    .eq("sensitivity", "sensitive");
  if (error) return 0;
  return count ?? 0;
}
