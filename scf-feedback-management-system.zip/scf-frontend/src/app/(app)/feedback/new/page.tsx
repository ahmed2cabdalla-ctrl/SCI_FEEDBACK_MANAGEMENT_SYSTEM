"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { useLookups } from "@/hooks/useLookups";
import { useAuth } from "@/lib/auth/AuthProvider";
import { Button, Card, ErrorState } from "@/components/ui";
import { SelectField, TextAreaField, TextField } from "@/components/ui/FormField";
import {
  CHANNEL_LABELS,
  PRIORITY_LABELS,
  TYPE_LABELS,
} from "@/lib/constants/labels";
import type {
  FeedbackChannel,
  FeedbackPriority,
  FeedbackSensitivity,
  FeedbackType,
} from "@/types/database";

const TYPE_OPTIONS = Object.entries(TYPE_LABELS).map(([value, label]) => ({ value, label }));
const CHANNEL_OPTIONS = Object.entries(CHANNEL_LABELS).map(([value, label]) => ({ value, label }));
const PRIORITY_OPTIONS = Object.entries(PRIORITY_LABELS).map(([value, label]) => ({ value, label }));
const SENSITIVITY_OPTIONS = [
  { value: "non_sensitive", label: "Non-sensitive" },
  { value: "sensitive", label: "Sensitive" },
];

function generateReferenceCode() {
  const stamp = Date.now().toString(36).toUpperCase();
  return `FB-${stamp}`;
}

export default function NewFeedbackPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { sectors, projects, locations, isLoading: lookupsLoading, error: lookupsError } =
    useLookups();

  const [type, setType] = useState<FeedbackType>("complaint");
  const [channel, setChannel] = useState<FeedbackChannel>("in_person");
  const [priority, setPriority] = useState<FeedbackPriority>("medium");
  const [sensitivity, setSensitivity] = useState<FeedbackSensitivity>("non_sensitive");
  const [category, setCategory] = useState("");
  const [sectorId, setSectorId] = useState("");
  const [projectId, setProjectId] = useState("");
  const [locationId, setLocationId] = useState("");
  const [description, setDescription] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!description.trim()) {
      setSubmitError("Please describe the feedback before submitting.");
      return;
    }

    setIsSubmitting(true);
    try {
      const supabase = createClient();
      const { error } = await supabase.from("feedback").insert({
        reference_code: generateReferenceCode(),
        type,
        channel,
        priority,
        sensitivity,
        status: "new",
        category: category || null,
        sector_id: sectorId || null,
        project_id: projectId || null,
        location_id: locationId || null,
        description: description.trim(),
        is_anonymous: isAnonymous,
        submitted_by: user?.id ?? null,
      });

      if (error) throw error;

      router.push("/feedback");
      router.refresh();
    } catch (err) {
      setSubmitError(
        err instanceof Error ? err.message : "Could not submit feedback. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (lookupsError) {
    return (
      <Card>
        <ErrorState
          title="Couldn't load form data"
          description={lookupsError}
        />
      </Card>
    );
  }

  return (
    <div className="mx-auto flex max-w-2xl flex-col gap-4">
      <Link
        href="/feedback"
        className="inline-flex w-fit items-center gap-1.5 text-sm font-medium text-ink-muted hover:text-ink"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        Back to feedback
      </Link>

      <Card className="p-6">
        <h2 className="text-base font-semibold text-ink">Log new feedback</h2>
        <p className="mt-1 text-sm text-ink-muted">
          Record a complaint, compliment, suggestion or inquiry received from a community member.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4" noValidate>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <SelectField
              label="Type"
              options={TYPE_OPTIONS}
              value={type}
              onChange={(e) => setType(e.target.value as FeedbackType)}
              required
            />
            <SelectField
              label="Channel received"
              options={CHANNEL_OPTIONS}
              value={channel}
              onChange={(e) => setChannel(e.target.value as FeedbackChannel)}
              required
            />
          </div>

          <TextField
            label="Category"
            placeholder="e.g. Distribution delay, Staff conduct, Access to services"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            hint="Free text for now — will become a managed list in Settings."
          />

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <SelectField
              label="Sector"
              placeholder={lookupsLoading ? "Loading…" : "Select a sector"}
              options={sectors}
              value={sectorId}
              onChange={(e) => setSectorId(e.target.value)}
              disabled={lookupsLoading}
            />
            <SelectField
              label="Project"
              placeholder={lookupsLoading ? "Loading…" : "Select a project"}
              options={projects}
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              disabled={lookupsLoading}
            />
            <SelectField
              label="Location"
              placeholder={lookupsLoading ? "Loading…" : "Select a location"}
              options={locations}
              value={locationId}
              onChange={(e) => setLocationId(e.target.value)}
              disabled={lookupsLoading}
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <SelectField
              label="Priority"
              options={PRIORITY_OPTIONS}
              value={priority}
              onChange={(e) => setPriority(e.target.value as FeedbackPriority)}
              required
            />
            <SelectField
              label="Sensitivity"
              options={SENSITIVITY_OPTIONS}
              value={sensitivity}
              onChange={(e) => setSensitivity(e.target.value as FeedbackSensitivity)}
              hint="Sensitive cases (e.g. safeguarding) follow restricted-access workflows."
              required
            />
          </div>

          <TextAreaField
            label="Description"
            placeholder="What did the community member report? Include relevant details, without recording more personal data than necessary."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />

          <label className="flex items-center gap-2 text-sm text-ink-muted">
            <input
              type="checkbox"
              checked={isAnonymous}
              onChange={(e) => setIsAnonymous(e.target.checked)}
              className="h-4 w-4 rounded border-gray-300 text-brand-600 focus:ring-brand-500"
            />
            Submitted anonymously
          </label>

          {submitError ? (
            <p role="alert" className="rounded-lg bg-brand-50 px-3 py-2 text-sm text-brand-700">
              {submitError}
            </p>
          ) : null}

          <div className="mt-2 flex justify-end gap-2">
            <Link href="/feedback">
              <Button type="button" variant="outline">
                Cancel
              </Button>
            </Link>
            <Button type="submit" isLoading={isSubmitting}>
              Submit feedback
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
