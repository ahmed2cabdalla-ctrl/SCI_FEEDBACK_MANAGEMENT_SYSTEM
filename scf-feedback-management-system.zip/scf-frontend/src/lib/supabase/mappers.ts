import type { FeedbackRecord, JoinedFeedbackRow } from "@/types";

/**
 * Maps a raw `feedback` row (joined with sector/project/location names) to
 * the flat `FeedbackRecord` shape used throughout the UI.
 */
export function mapFeedbackRow(row: JoinedFeedbackRow): FeedbackRecord {
  return {
    id: row.id,
    referenceCode: row.reference_code,
    type: row.type,
    category: row.category,
    channel: row.channel,
    sensitivity: row.sensitivity,
    priority: row.priority,
    status: row.status,
    isAnonymous: row.is_anonymous,
    description: row.description,
    sectorName: row.sectors?.name ?? null,
    projectName: row.projects?.name ?? null,
    locationName: row.locations?.name ?? null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    resolvedAt: row.resolved_at,
  };
}
