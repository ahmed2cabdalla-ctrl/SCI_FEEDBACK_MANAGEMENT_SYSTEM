-- Reference schema for the Feedback Management System.
--
-- This is a STARTING POINT that matches the queries written in the frontend
-- (src/hooks/*, src/types/database.ts). Adjust table/column names to match
-- your organisation's real Supabase project, then either:
--   a) edit this file and run it against your project, or
--   b) keep your existing schema and update the frontend queries to match it.
--
-- Row Level Security (RLS) policies below are intentionally minimal
-- placeholders — review and harden them (especially for `beneficiaries`
-- and `feedback.sensitivity = 'sensitive'` rows) before going to production.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- Reference / lookup tables
-- ---------------------------------------------------------------------------

create table if not exists public.sectors (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.locations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  type text not null check (type in ('country', 'region', 'district', 'community')),
  parent_id uuid references public.locations (id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text,
  sector_id uuid references public.sectors (id) on delete set null,
  location_id uuid references public.locations (id) on delete set null,
  status text not null default 'active' check (status in ('planned', 'active', 'closed')),
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- People
-- ---------------------------------------------------------------------------

-- Extends Supabase's built-in auth.users with app-specific profile fields.
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null,
  role text not null default 'viewer'
    check (role in ('admin', 'accountability_officer', 'program_staff', 'viewer')),
  avatar_url text,
  location_id uuid references public.locations (id) on delete set null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Minimal, privacy-conscious beneficiary record — store only what
-- accountability workflows genuinely need.
create table if not exists public.beneficiaries (
  id uuid primary key default gen_random_uuid(),
  unique_code text not null unique,
  full_name text,
  gender text check (gender in ('female', 'male', 'other', 'unspecified')),
  age_group text check (age_group in ('child', 'youth', 'adult', 'elderly')),
  location_id uuid references public.locations (id) on delete set null,
  project_id uuid references public.projects (id) on delete set null,
  contact_phone text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Feedback
-- ---------------------------------------------------------------------------

create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  reference_code text not null unique,
  type text not null check (type in ('complaint', 'compliment', 'suggestion', 'inquiry')),
  category text,
  sector_id uuid references public.sectors (id) on delete set null,
  project_id uuid references public.projects (id) on delete set null,
  location_id uuid references public.locations (id) on delete set null,
  beneficiary_id uuid references public.beneficiaries (id) on delete set null,
  channel text not null check (
    channel in ('hotline', 'in_person', 'suggestion_box', 'sms', 'email', 'community_meeting', 'other')
  ),
  sensitivity text not null default 'non_sensitive' check (sensitivity in ('sensitive', 'non_sensitive')),
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high', 'critical')),
  status text not null default 'new' check (
    status in ('new', 'in_progress', 'resolved', 'closed', 'escalated')
  ),
  is_anonymous boolean not null default false,
  description text not null,
  response text,
  submitted_by uuid references public.profiles (id) on delete set null,
  assigned_to uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  resolved_at timestamptz
);

create index if not exists feedback_created_at_idx on public.feedback (created_at desc);
create index if not exists feedback_status_idx on public.feedback (status);
create index if not exists feedback_sensitivity_idx on public.feedback (sensitivity);

create table if not exists public.hotline_calls (
  id uuid primary key default gen_random_uuid(),
  caller_reference text,
  call_type text not null check (call_type in ('inbound', 'outbound')),
  duration_seconds integer,
  feedback_id uuid references public.feedback (id) on delete set null,
  handled_by uuid references public.profiles (id) on delete set null,
  notes text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Row Level Security (placeholder policies — review before production use)
-- ---------------------------------------------------------------------------

alter table public.profiles enable row level security;
alter table public.sectors enable row level security;
alter table public.locations enable row level security;
alter table public.projects enable row level security;
alter table public.beneficiaries enable row level security;
alter table public.feedback enable row level security;
alter table public.hotline_calls enable row level security;

-- Any authenticated staff member can read reference/lookup data.
create policy "authenticated read sectors" on public.sectors
  for select to authenticated using (true);
create policy "authenticated read locations" on public.locations
  for select to authenticated using (true);
create policy "authenticated read projects" on public.projects
  for select to authenticated using (true);

-- Feedback: authenticated staff can read and create; tighten update/delete
-- to admins/accountability officers via a custom check on public.profiles.role.
create policy "authenticated read feedback" on public.feedback
  for select to authenticated using (true);
create policy "authenticated insert feedback" on public.feedback
  for insert to authenticated with check (true);

create policy "users read own profile" on public.profiles
  for select to authenticated using (auth.uid() = id);
