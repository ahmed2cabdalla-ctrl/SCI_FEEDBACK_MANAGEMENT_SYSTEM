# Feedback Management System — Frontend

A responsive Next.js + TypeScript + Tailwind + Supabase frontend for a humanitarian
accountability feedback management system.

## Branding note

The brief asked for the Save the Children logo, but it also said not to use the real
logo unless supplied — so this build uses a generic placeholder mark (`src/components/layout/Logo.tsx`)
and a humanitarian red/white colour palette (`tailwind.config.ts`), not the actual
Save the Children brand. Drop your official logo file into `public/` and swap the
icon in `Logo.tsx` for an `<Image>` tag whenever you have the asset.

## Stack

- Next.js 14 (App Router) + TypeScript (strict)
- Tailwind CSS
- Supabase (`@supabase/ssr` + `@supabase/supabase-js`) for auth + data
- Lucide React for icons
- Recharts for charts

## Getting started

```bash
npm install
cp .env.local.example .env.local   # then fill in your Supabase project URL + anon key
npm run dev
```

The app expects a Supabase schema roughly matching `supabase/schema.sql` — see that
file's comments. If your real project uses different table/column names, either
adjust the SQL to match your project or update the queries in `src/hooks/*.ts` and
`src/types/database.ts` to match your schema.

## What's implemented in this pass

Per the brief, only the foundation + the Dashboard and Feedback modules are wired up
to real Supabase data. Every other module route exists and renders inside the shared
shell, but shows a "planned features" placeholder (`ModulePlaceholder`) instead of a
full implementation — build these out next, reusing the same Card / DataTable /
FilterBar / Modal / FormField components.

Every data-driven page has explicit loading, empty and error states — nothing is
mocked; if Supabase isn't configured or a query fails, you'll see a real error state
with a retry button, not fake data.

## File map

```
.env.local.example              Copy to .env.local and fill in Supabase credentials
supabase/schema.sql              Reference SQL schema matching the queries in this app
middleware.ts                    Root middleware: refreshes Supabase session, guards routes

src/types/database.ts            Hand-written Supabase table types (regenerate from your real project)
src/types/index.ts                Domain types (FeedbackRecord, DashboardStats, AsyncState, ...)

src/lib/supabase/client.ts       Browser Supabase client
src/lib/supabase/server.ts       Server Component / Route Handler Supabase client
src/lib/supabase/middleware.ts   Session refresh + auth redirect logic used by middleware.ts
src/lib/auth/AuthProvider.tsx    React context exposing session/profile/role + signOut()
src/lib/utils/cn.ts              Tailwind class-merge helper
src/lib/utils/date.ts            Date formatting helpers
src/lib/constants/nav.ts         Sidebar navigation config
src/lib/constants/labels.ts      Status/priority/type/channel labels + colours

src/components/ui/Card.tsx        Card, CardHeader, CardBody, StatCard
src/components/ui/Badge.tsx       Badge, StatusBadge, PriorityBadge
src/components/ui/Button.tsx      Button (variants, sizes, loading state)
src/components/ui/FormField.tsx   TextField, TextAreaField, SelectField
src/components/ui/Modal.tsx       Accessible modal dialog
src/components/ui/States.tsx      LoadingState, SkeletonRows, EmptyState, ErrorState
src/components/ui/Table.tsx       Generic DataTable<T> (handles loading/empty/error itself)
src/components/ui/FilterBar.tsx   Search box + dropdown filters used on list pages
src/components/ui/index.ts        Barrel export for the above

src/components/layout/Logo.tsx              Placeholder org mark (see branding note)
src/components/layout/Sidebar.tsx           Desktop sidebar + shared SidebarContent
src/components/layout/TopNav.tsx            Sticky top bar: mobile menu button, user menu, sign out
src/components/layout/DashboardShell.tsx    App shell: sidebar + mobile drawer + top nav + content
src/components/layout/ModulePlaceholder.tsx Scaffold shown by not-yet-built modules

src/components/dashboard/StatsOverview.tsx           Headline stat tiles
src/components/dashboard/FeedbackTrendChart.tsx       14-day submissions area chart (Recharts)
src/components/dashboard/CategoryBreakdownChart.tsx   Top categories bar chart (Recharts)
src/components/dashboard/StatusDistributionChart.tsx  Status distribution pie chart (Recharts)
src/components/dashboard/RecentFeedbackTable.tsx      Recent feedback DataTable

src/hooks/useDashboardData.ts    Fetches all dashboard stats/charts/recent list from Supabase
src/hooks/useFeedbackList.ts     Fetches feedback records for the Feedback list page
src/hooks/useLookups.ts          Fetches sectors/projects/locations for form dropdowns

src/app/layout.tsx                        Root layout: <html>/<body>, mounts AuthProvider
src/app/globals.css                       Tailwind entrypoint + base styles
src/app/page.tsx                          Redirects "/" -> "/dashboard"
src/app/login/page.tsx                    Sign-in page
src/app/login/LoginForm.tsx               Sign-in form (Supabase email/password auth)
src/app/(app)/layout.tsx                  Auth-gated layout wrapping every module in DashboardShell
src/app/(app)/dashboard/page.tsx          Dashboard (fully implemented)
src/app/(app)/feedback/page.tsx           Feedback list (fully implemented: search + filters + table)
src/app/(app)/feedback/new/page.tsx       New feedback form (fully implemented: real Supabase insert)
src/app/(app)/beneficiaries/page.tsx      Placeholder
src/app/(app)/sectors/page.tsx            Placeholder
src/app/(app)/projects/page.tsx           Placeholder
src/app/(app)/locations/page.tsx          Placeholder
src/app/(app)/hotline/page.tsx            Placeholder
src/app/(app)/reports/page.tsx            Placeholder
src/app/(app)/users/page.tsx              Placeholder
src/app/(app)/settings/page.tsx           Placeholder
```

## Notes on accessibility & responsiveness

- Sidebar collapses into a slide-over drawer below the `lg` breakpoint; the top nav
  exposes a menu button that opens it.
- All interactive elements (buttons, form fields, modal) have visible focus states,
  labels and `aria-*` attributes.
- Tables scroll horizontally on narrow screens instead of breaking the page layout;
  secondary columns hide on mobile via `hideOnMobile`.
- Colour choices for status/priority badges pass WCAG AA contrast against white.
