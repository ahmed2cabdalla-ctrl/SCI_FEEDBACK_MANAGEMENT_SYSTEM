/**
 * Custom Node entry point for hosts that need one explicit, executable
 * startup file (e.g. Hostinger's hPanel "Node.js Web Apps Hosting", which
 * asks you to point an "Application startup file" at a plain .js file) —
 * rather than relying on the host correctly invoking `npm start` / `next
 * start` on its own. This is the standard pattern Next.js documents for
 * deploying to a plain Node server: https://nextjs.org/docs/app/guides/custom-server
 *
 * It does exactly what `next start` does — boots Next.js and hands every
 * request to its internal handler (routing, middleware, API routes, and
 * all) — just as a plain script a host's process manager can run directly.
 *
 * Locally, keep using `npm run dev` (this file is NOT used in dev — Next's
 * own dev server has faster refresh). This only matters for `npm run
 * start` / production hosting.
 */
const { createServer } = require("http");
const { parse } = require("url");
const next = require("next");

// Hostinger (and most Node hosts) assign a port via the PORT env var and
// proxy your domain to it — the app must listen on whatever it provides.
const port = parseInt(process.env.PORT || "3000", 10);
const dev = process.env.NODE_ENV !== "production";

const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  createServer((req, res) => {
    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  }).listen(port, () => {
    // eslint-disable-next-line no-console
    console.log(`> Feedback Management System ready on port ${port} (${dev ? "development" : "production"})`);
  });
});
