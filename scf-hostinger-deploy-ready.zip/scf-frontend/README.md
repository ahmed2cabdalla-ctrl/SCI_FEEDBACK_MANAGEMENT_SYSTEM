# Feedback Management System — Frontend

A responsive Next.js + TypeScript + Tailwind frontend for a humanitarian
accountability feedback management system.

## Architecture: two backends, on purpose

This app splits its backend across two services:

- **Supabase** — staff authentication and the `profiles` table only (name + role).
  See `/supabase/schema.sql`.
- **Airtable** — every actual piece of case data: feedback, sectors, projects,
  locations, beneficiaries, hotline calls. See `/airtable/schema.md`. This is
  what gives accountability staff a spreadsheet-simple way to browse and edit
  records directly, without touching this app's code.

Airtable has no row-level security of its own and its access token must never
reach the browser, so **all Airtable access happens server-side**, through
Next.js Route Handlers under `src/app/api/` (`/api/dashboard`, `/api/feedback`,
`/api/lookups`). Every one of those routes checks the caller has a valid
Supabase session before touching Airtable at all — that's the only gate
protecting the data, since Airtable itself won't enforce one.

## Branding note

The brief asked for the Save the Children logo, but it also said not to use the real
logo unless supplied — so this build uses a generic placeholder mark (`src/components/layout/Logo.tsx`)
and a humanitarian red/white colour palette (`tailwind.config.ts`), not the actual
Save the Children brand. Drop your official logo file into `public/` and swap the
icon in `Logo.tsx` for an `<Image>` tag whenever you have the asset.

## Stack

- Next.js 14 (App Router) + TypeScript (strict)
- Tailwind CSS
- Supabase (`@supabase/ssr` + `@supabase/supabase-js`) for staff login only
- Airtable REST API (plain `fetch`, no SDK) for all case data, called only from server-side route handlers
- Lucide React for icons
- Recharts for charts

## Getting started

```bash
npm install
cp .env.local.example .env.local   # then fill in BOTH your Supabase and Airtable credentials
npm run dev
```

You need both backends configured for the app to do anything real:

1. **Supabase** — create a project, run `supabase/schema.sql` in its SQL editor, and
   create at least one user (Authentication → Users) with a matching `profiles` row.
2. **Airtable** — create a base matching `/airtable/schema.md` exactly (table/field
   names and Single Select choice text are matched by exact string), and a Personal
   Access Token scoped to it.

Until both are filled in, pages won't fake data — they'll show their real error state
(missing/invalid credentials surfaces as a normal fetch failure), exactly as before.

## Deploying to Hostinger

Hostinger's plain shared/business hosting runs on their own **hPanel**, not real cPanel —
cPanel there is only a paid add-on for VPS plans. Whichever one you actually have changes
how you deploy, since this is a real Node.js server app (auth, API routes, live Airtable
queries) — it can't be hosted as static files.

**If you have Hostinger's standard hosting (hPanel)** — most likely case: use hPanel's
built-in **"Node.js Web Apps Hosting"** feature (Websites → your domain → Node.js). Steps:

1. Upload the project (Git deployment from your repo, or the File Manager/FTP) to the
   application's root folder. Make sure `public_html` for that domain is otherwise empty —
   a leftover `index.html` or old `.htaccess` from a previous site on that domain can
   block the Node app's own proxy rules and is a common cause of a generic 403 page.
2. In the Node.js app screen, set the Node version to 20+, then use its "Run NPM Install"
   button (equivalent to `npm install`).
3. Add your environment variables — `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`,
   `AIRTABLE_PERSONAL_ACCESS_TOKEN`, `AIRTABLE_BASE_ID` — in that same screen; `.env.local`
   is git-ignored and won't exist on the server.
4. **Run the build.** `npm install` alone isn't enough — either use a "Run build command"
   field if hPanel offers one, or open the app's Terminal/SSH access and run `npm run build`
   yourself. Without this there's no `.next` output for the app to serve, and it will fail
   to start.
5. Set the **Application startup file** to `server.js` (included in this project, at the
   root). This app doesn't rely on Hostinger correctly guessing how to run `next start` —
   `server.js` is a plain, explicit Node entry point that starts Next.js and listens on
   whatever `PORT` Hostinger assigns, so there's nothing for the host to misconfigure.
6. Restart the app from the panel, then check its status shows "Running" and its Logs tab
   for errors before testing the URL.

**If you have a genuine cPanel (VPS + cPanel license)**: cPanel's classic Node.js Selector
(Passenger) isn't guaranteed to be bundled with Hostinger's VPS cPanel license. The more
reliable path there is to treat it like any VPS: SSH in, install Node via `nvm`, run
`npm install && npm run build`, then keep it running with a process manager like `pm2`
(`pm2 start npm --name feedback-system -- start`) behind an Nginx/Apache reverse proxy
that forwards your domain to `localhost:3000` (or whatever port you choose).

Either way, test `npm run build && npm run start` locally first and confirm the app
boots cleanly before uploading — that isolates hosting-specific problems from app bugs.

## What's implemented in this pass

Per the brief, only the foundation + the Dashboard and Feedback modules are wired up
to real data. Every other module route exists and renders inside the shared shell, but
shows a "planned features" placeholder (`ModulePlaceholder`) instead of a full
implementation — build these out next, reusing the same Card / DataTable / FilterBar /
Modal / FormField components, and the same server-route-handler pattern for talking to
Airtable.

Every data-driven page has explicit loading, empty and error states — nothing is
mocked; if either backend isn't configured or a request fails, you'll see a real error
state with a retry button, not fake data.

## File map

```
.env.local.example               Copy to .env.local — needs BOTH Supabase and Airtable credentials
server.js                         Explicit Node entry point for hosts like Hostinger that need one (see "Deploying to Hostinger")
supabase/schema.sql               Reference SQL: Supabase's `profiles` table only
airtable/schema.md                Airtable base/table/field setup guide (no SQL equivalent — built via Airtable's UI)
middleware.ts                     Root middleware: refreshes Supabase session, guards routes

src/types/database.ts             Supabase types: profiles/auth only (regenerate from your real project)
src/types/feedback.ts             Feedback domain enums (type/channel/status/priority/sensitivity)
src/types/index.ts                Domain types (FeedbackRecord, DashboardStats, AsyncState, ...)

src/lib/supabase/client.ts        Browser Supabase client (auth only)
src/lib/supabase/server.ts        Server Component Supabase client (auth only)
src/lib/supabase/middleware.ts    Session refresh + auth redirect logic used by middleware.ts
src/lib/supabase/config.ts        Safe env var fallback so a missing config never crashes the build
src/lib/supabase/requireUser.ts   Auth guard called by every /api/* route before touching Airtable
src/lib/auth/AuthProvider.tsx     React context exposing session/profile/role + signOut()

src/lib/airtable/config.ts        Server-only Airtable env var resolution (AIRTABLE_PERSONAL_ACCESS_TOKEN, AIRTABLE_BASE_ID)
src/lib/airtable/client.ts        Low-level Airtable REST wrapper (pagination, create, 429 backoff) — server-only
src/lib/airtable/tables.ts        Table/field name constants — must match your Airtable base exactly
src/lib/airtable/valueMaps.ts     Translates Airtable's display-text choices <-> this app's internal enum values
src/lib/airtable/mappers.ts       Maps raw Airtable records to the app's flat FeedbackRecord/SelectOption shapes

src/lib/utils/cn.ts               Tailwind class-merge helper
src/lib/utils/date.ts             Date formatting helpers
src/lib/constants/nav.ts          Sidebar navigation config
src/lib/constants/labels.ts       Status/priority/type/channel/sensitivity labels + colours (single source of truth, also used by valueMaps.ts)

src/app/api/dashboard/route.ts    GET — all dashboard stats/trend/breakdowns, computed server-side from Airtable
src/app/api/feedback/route.ts     GET list / POST create — reads and writes the Airtable Feedback table
src/app/api/lookups/route.ts      GET — sectors/projects/locations dropdown options from Airtable

src/components/ui/Card.tsx        Card, CardHeader, CardBody, StatCard
src/components/ui/Badge.tsx       Badge, StatusBadge, PriorityBadge
src/components/ui/Button.tsx      Button (variants, sizes, loading state)
src/components/ui/FormField.tsx   TextField, TextAreaField, SelectField
src/components/ui/Modal.tsx       Accessible modal dialog
src/components/ui/States.tsx      LoadingState, SkeletonRows, EmptyState, ErrorState
src/components/ui/Table.tsx       Generic DataTable<T> (handles loading/empty/error itself)
src/components/ui/FilterBar.tsx   Search box + dropdown filters used on list pages
src/components/ui/index.ts        Barrel export for the above

src/components/layout/Logo.tsx              Placeholder org mark (see branding note)
src/components/layout/Sidebar.tsx           Desktop sidebar + shared SidebarContent
src/components/layout/TopNav.tsx            Sticky top bar: mobile menu button, user menu, sign out
src/components/layout/DashboardShell.tsx    App shell: sidebar + mobile drawer + top nav + content
src/components/layout/ModulePlaceholder.tsx Scaffold shown by not-yet-built modules

src/components/dashboard/StatsOverview.tsx           Headline stat tiles
src/components/dashboard/FeedbackTrendChart.tsx       14-day submissions area chart (Recharts)
src/components/dashboard/CategoryBreakdownChart.tsx   Top categories bar chart (Recharts)
src/components/dashboard/StatusDistributionChart.tsx  Status distribution pie chart (Recharts)
src/components/dashboard/RecentFeedbackTable.tsx      Recent feedback DataTable

src/hooks/useDashboardData.ts     Fetches /api/dashboard for the Dashboard page
src/hooks/useFeedbackList.ts      Fetches /api/feedback for the Feedback list page
src/hooks/useLookups.ts           Fetches /api/lookups for form dropdowns

src/app/layout.tsx                        Root layout: <html>/<body>, mounts AuthProvider
src/app/globals.css                       Tailwind entrypoint + base styles
src/app/page.tsx                          Redirects "/" -> "/dashboard"
src/app/login/page.tsx                    Sign-in page
src/app/login/LoginForm.tsx               Sign-in form (Supabase email/password auth)
src/app/(app)/layout.tsx                  Auth-gated layout wrapping every module in DashboardShell
src/app/(app)/dashboard/page.tsx          Dashboard (fully implemented)
src/app/(app)/feedback/page.tsx           Feedback list (fully implemented: search + filters + table)
src/app/(app)/feedback/new/page.tsx       New feedback form (fully implemented: real Airtable insert via /api/feedback)
src/app/(app)/beneficiaries/page.tsx      Placeholder
src/app/(app)/sectors/page.tsx            Placeholder
src/app/(app)/projects/page.tsx           Placeholder
src/app/(app)/locations/page.tsx          Placeholder
src/app/(app)/hotline/page.tsx            Placeholder
src/app/(app)/reports/page.tsx            Placeholder
src/app/(app)/users/page.tsx              Placeholder
src/app/(app)/settings/page.tsx           Placeholder
```

## Notes on accessibility & responsiveness

- Sidebar collapses into a slide-over drawer below the `lg` breakpoint; the top nav
  exposes a menu button that opens it.
- All interactive elements (buttons, form fields, modal) have visible focus states,
  labels and `aria-*` attributes.
- Tables scroll horizontally on narrow screens instead of breaking the page layout;
  secondary columns hide on mobile via `hideOnMobile`.
- Colour choices for status/priority badges pass WCAG AA contrast against white.
